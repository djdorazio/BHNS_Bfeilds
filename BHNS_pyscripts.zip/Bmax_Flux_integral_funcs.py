import numpy as np
import math as ma
import scipy as sc
# from scipy import optimize
import scipy.optimize as opt
import scipy.integrate as intg
import matplotlib
#matplotlib.use('Agg')

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
matplotlib.rcParams['font.family'] = 'sans-serif'
matplotlib.rcParams['font.sans-serif'] = ['Helvetica']
matplotlib.rcParams.update({'font.size': 16})
import matplotlib.pyplot as plt

plt.rcParams.update({
    "text.usetex": True,
    "font.family": "sans-serif",
    "font.sans-serif": ["Helvetica"]})

################################################
#Physical Constants
################################################
G    = 6.67384*10.**(-8)
c    = 2.99792458*10.**(10)
Msun = 1.989*10.**33
hplnk = 6.62607*10**(-27) ##(*Planks constant (erg * s)  *)
kb = 1.3807*10**(-16)
me = 9.109*10**(-28)
sigT = 6.652*10**(-25) #(*Thompson scattering cross section 
sigSB = 5.670*10**(-5) #Stef Boltz

pc2cm = 3.08567758*10**(18)
eVperErg = 1./6.242e+11



##################
### COSMOLOGY FUNCS
###################
hub = 0.679 # 0.7  
Om = 0.3065#0.3
OL = 1.0-Om #0.7
### Ee defined 1/(sqrt(Om(1+z)^3 + OmL))
def OneoEe(z, Om, OL):
    if (type(z) is float or type(z) is np.float64):
        return 1./ma.sqrt( (1.+z)**3 * Om  +  OL )
    else:
        res=[]
        for i in range(len(z)):
            res.append(1./ma.sqrt( (1.+z[i])**3 * Om  +  OL ))
        return np.array(res)


def Dang(z, hub, Om, OL):
    H0 = 100.*hub #kms Mpc^{-1}
    DH = c/(H0 *10.**5/(10.**6*pc2cm))
    tH = DH/c

    if (type(z) is float or type(z) is np.float64):
        return  DH/(1.+ z) * intg.quad(OneoEe, 0., z, args=(Om,OL), epsabs=0.0)[0]
    else:
        res=[]
        for i in range(len(z)):
            res.append( DH/(1.+ z[i]) * intg.quad(OneoEe, 0., z[i], args=(Om,OL), epsabs=0.0)[0] )
    return np.array(res)


def DL(z, hub, Om, OL):
    return (1.+z)**2*Dang(z, hub, Om, OL)

def DLtoZ_func(log10z, DLtarg):
    return  DLtarg - DL(10**log10z, hub, Om, OL)

def DLtoZ(DLtarg):
    return 10**opt.brentq(DLtoZ_func, -4, 1., args=(DLtarg))



def RH(MBH, spin_parm):
    return G*MBH/c**2 * (1. + np.sqrt( 1. - spin_parm**2) )


def Omorb(MBH, MNS, asep):
    return np.sqrt(G*(MBH+MNS)/asep**3)

def asepmin(RNS, MBH, spin_parm):
    #RNS = 10.**6 #10km
    #return RNS + RH(MBH, spin_parm)
    return RH(MBH, spin_parm)

def VH(BNS, MBH, MNS, spin_parm, asep, OmNS):
    RNS = 10.**6 #10km
    r = max(asep, asepmin(RNS, MBH, spin_parm))
    #r = max(asep, RH(MBH, spin_parm))
    return 2. * RH(MBH, spin_parm) * ( r*(Omorb(MBH, MNS, r) - OmNS)/c + spin_parm/(4.*np.sqrt(2.)) ) * BNS * (RNS/r)**3


def Pow_supply(BNS, MBH, MNS, spin_parm, asep, OmNS):
    ResBH = 4.*np.pi/c
    ResNS = ResBH ##Impedence matching
    # should this 2 be here?  Accounting for both hemispheres 
    return 2.*(VH(BNS, MBH, MNS, spin_parm, asep, OmNS))**2/(ResBH + ResNS)**2 * ResNS




################
### flux calculation adapted from from Mathemtaic notebook 
################

# def tG(M):
#     return G*M/c**3 

# # tstart = Make this scale with M...
# t1st3 = 0.0004909635/ tG(M10)
# t1st2 = 0.00009698/ tG(M10)
# t1st1 = 0.00000602007/ tG(M10)
# tstart = t1st1


# def Tdec(M, MNS):
#     OmNS = 1.
#     Rstrt = c/OmNS
#     return Rstrt**4/(4.*(64./5.*G**3/c**5*MNS*M *(M + MNS)) )

# def rr0(Ng0, MBH, MNS):
#     return Ng*G*MBH/c**2 #+ RNS
#     # OmNS = 1.
#     # Rstrt = c/OmNS
#     # return  (  (Rstrt)**4 - 4.*(64./5.*G**3/c**5*MNS*M*(M + MNS)*(Tdec(M) - t) ) )**(1./4.)


##at separation given by r,M, changed frim t, M in mathematica
#DD adding r0 param instead of hardcoding Sep 30 2021
def KTinSep(log10BNS, MBH, MNS, spin_parm, asep, OmNS, r0): 
    #r0 = asep/2.  #G*MBH/c**2 ## input for rr0 is the binary sep, so make a sphere with radius asep/2
    return kb * ( Pow_supply(10**log10BNS, MBH, MNS, spin_parm, asep, OmNS)/(4.*np.pi*r0**2 * sigSB) )**(0.25)    
    # return kb * ( Pow_supply(10**log10BNS, MBH, MNS, spin_parm, rr0, OmNS)/(4.*np.pi*rr0**2 * sigSB) )**(0.25)
    # return kb*(Lum[t, M, BNS]/(4*Pi*(rr[t, M])^2 * sigSB )  )^(1/4)

def KTExpR(Rph, log10BNS, MBH, MNS, spin_parm, asep, OmNS, r0):
    #r0 = asep/2.  #G*MBH/c**2 ## input for rr0 is the binary sep, so make a sphere with radius asep/2
    return KTinSep(log10BNS, MBH, MNS, spin_parm, asep, OmNS, r0)*r0/Rph


# (*Maxwell number dist*)
def nMxwl(T): 
    return 4.*np.pi/hplnk**3 * np.sqrt(np.pi)*(2.*me*kb*T)**(1.5) * np.exp(-(me*c**2)/(kb*T))

#(*Electron scattering photosphere*)
def Rph_fnc(Rph, log10BNS, MBH, MNS, spin_parm, asep, OmNS, r0):
    return G*MBH/c**2*Rph*sigT*nMxwl(KTExpR(G*MBH/c**2*Rph, log10BNS, MBH, MNS, spin_parm, asep, OmNS, r0)/kb) - 1.

def Rph(log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0):
    #return (G*M/c**2)*sc.brentq(G*10*Msun/c^2*R*sigT*nMxwl[KTExpR[t, M, BNS, R*G*10*Msun/c^2]/kb] == 1, {R, 1, 1000}]
    return (G*MBH/c**2)*opt.brentq(Rph_fnc, 0.1, 2000, args=(log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0))


#Rphfit1M[slope_, log10BNS_] := slope*log10BNS + (6.80345 - slope*12)
#Rphfit2M[slope_, log10BNS_] := slope*log10BNS + (6.4267 - slope*12)
# def Rphfit_1M(log10BNS):
#     slope = 0.518
#     intcpt = 6.80345 #at log10BNS=12
#     return slope*log10BNS + (6.80345 - slope*12)

# def GamQuick(Ng0, MBH, MNS, log10BNS):
#     return min(1., 10**Rphfit_1M(log10BNS)/rr0(Ng0, MBH, MNS))

def GamQuick(log10BNS, MBH, MNS, spin_parm, asep, OmNS, r0):
    #r0 = asep/2.  #G*MBH/c**2#r0 = asep/2. ## input for rr0 is the binary sep, so make a sphere with radius asep/2
    return max( 1., Rph(log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0)/r0 )


## frac fo sphere in 1/gamma cone, *1.6 to match full integral
def AreaFrac(Gam):
    return 0.5*( 1. - np.cos(1./Gam) ) * 1.6




## from mathemtaica fit
#KTexpRfit1M[slope_, log10BNS_] := slope*log10BNS + (-7.49663 - slope*12)
#KTexpRfit2M[slope_, log10BNS_] := slope*log10BNS + (-7.48256 - slope*12)
# def KTexpRfit_1M(log10BNS)
#     slope = -0.0181
#     intcpt = -7.49663 #at log10BNS=12
#     return slope*log10BNS + (intcpt - slope*12)


# def E_REl_BB_APRX(nu, Rphot, z, log10BNS, MBH, MNS, spin_parm, rr0, OmNS):
#     earg = (1. + z) * hplnk * nu/( GamQuick(log10BNS, MBH, MNS, spin_parm, rr0, OmNS) * KTExpR(Rphot, log10BNS, MBH, MNS, spin_parm, rr0, OmNS) )
#     return 2. * nu**2/c**2/(np.exp( earg ) - 1.)


# def E_REl_BB_APRX(log10nu, Rphot, z, log10BNS, MBH, MNS, spin_parm, asep, OmNS):
#     earg = (1. + z) * hplnk * 10**log10nu/( GamQuick(log10BNS, MBH, MNS, spin_parm, asep, OmNS) * KTExpR(Rphot, log10BNS, MBH, MNS, spin_parm, asep, OmNS) )
#     dlogfac = (np.log(10) * 10**log10nu) ## integrate over log10(nu) (dx = x*ln(10)*dlog10(x))
#     # return dlogfac * 2. * hplnk*10**log10nu * (10**log10nu)**2/c**2/(np.exp( earg ) - 1.)
#     return dlogfac * 2. * hplnk * 10**log10nu *(10**log10nu)**2/c**2/(np.exp( earg ) - 1.)


###
## Consistent with DA 
## THE (1+z) must be there to account for redshifted BB temp for the same reason that we use the boosted Temp = D*T_ph = DT_0)
## remember that nu is just an integration variable and vmin vmax set limits of BB to integrate over in observer frame
# ###
def E_REl_BB_APRX(log10nu, Rphot, z, log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0):
    earg = (1. + z) * hplnk * 10**log10nu/( KTinSep(log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0) ) ##KTIntsep is gamma*Texp = T_0, when we get rid of full Doppler term in the approx
    dlogfac = (np.log(10) * 10**log10nu) ## integrate over log10(nu) (dx = x*ln(10)*dlog10(x))
    # return dlogfac * 2. * hplnk*10**log10nu * (10**log10nu)**2/c**2/(np.exp( earg ) - 1.)
    return dlogfac * 2. * hplnk * 10**log10nu *(10**log10nu)**2/c**2/(np.exp( earg ) - 1.)

# ### Consistent with DL
# def E_REl_BB_APRX(log10nu, Rphot, z, log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0):
#     earg = hplnk * 10**log10nu/( KTinSep(log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0) ) ##KTIntsep is gamma*Texp = T_0, when we get rid of full Doppler term in the approx
#     dlogfac = (np.log(10) * 10**log10nu) ## integrate over log10(nu) (dx = x*ln(10)*dlog10(x))
#     # return dlogfac * 2. * hplnk*10**log10nu * (10**log10nu)**2/c**2/(np.exp( earg ) - 1.)
#     return dlogfac * 2. * hplnk * 10**log10nu *(10**log10nu)**2/c**2/(np.exp( earg ) - 1.)




# def EgyFreqFluxAPRX_z(numin, numax, log10BNS, MBH, MNS, spin_parm, rr0, OmNS):
#     Rphot = Rph(log10BNS, MBH, MNS, spin_parm, rr0, OmNS)
#     prefac = 4.*np.pi*AreaFrac(GamQuick(log10BNS, MBH, MNS, spin_parm, rr0, OmNS)) * ( Rphot/Dang(z, hub, Om, OL) )**2
#     return prefac * sc.integrate.quad(E_REl_BB_APRX, numin, numax, args=(Rphot, z, log10BNS, MBH, MNS, spin_parm, rr0, OmNS))[0]

###
## Consistent with* DA and with (1+z) in eearg!
## DA from the flux integral over solid angle giving ~Rph/DA when redshifted with nu
###
def EgyFreqFluxAPRX(log10numin, log10numax, z, log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0):
    Rphot = Rph(log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0) 
    # if no is obs nu, then shoudl be DA
    prefac = 4.*np.pi*AreaFrac(GamQuick(log10BNS, MBH, MNS, spin_parm, asep, OmNS, r0)) * ( Rphot/Dang(z, hub, Om, OL) )**2
    ## should be DL in observer frame nu^3 dnu gives (1+z)^4 and DL^2 = (1+z)^4 DA^2 --!! if nu is emitted nu!
    #prefac = 4.*np.pi*AreaFrac(GamQuick(log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0)) * ( Rphot/DL(z, hub, Om, OL) )**2
    return prefac*sc.integrate.quad(E_REl_BB_APRX, log10numin, log10numax, args=(Rphot, z, log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0))[0]

## Consistent with DL and without* (1+z) in eearg!
##/DL^2 because we are using relation Lum = Fobs * Area_obs = Fph * Aph, and in an expanding universe, F/L = 1/((1+z)^2 A) = 1/(4 pi Dl^2) (See Carroll page 347)
# def EgyFreqFluxAPRX(log10numin, log10numax, z, log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0):
#     Rphot = Rph(log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0) 
#     # if no is obs nu, then shoudl be DA
#     prefac = 4.*np.pi*AreaFrac(GamQuick(log10BNS, MBH, MNS, spin_parm, asep, OmNS, r0)) * ( Rphot/DL(z, hub, Om, OL) )**2
#     ## should be DL in observer frame nu^3 dnu gives (1+z)^4 and DL^2 = (1+z)^4 DA^2 --!! if nu is emitted nu!
#     #prefac = 4.*np.pi*AreaFrac(GamQuick(log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0)) * ( Rphot/DL(z, hub, Om, OL) )**2
#     return prefac*sc.integrate.quad(E_REl_BB_APRX, log10numin, log10numax, args=(Rphot, z, log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0))[0]



def Zmax_func(log10z, Enrgy_targ, log10numin, log10numax, log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0):
    return EgyFreqFluxAPRX(log10numin, log10numax, 10**log10z, log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0) - Enrgy_targ


def Zmax(Enrgy_targ, log10numin, log10numax, log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0):
    return opt.brentq(Zmax_func, -4, 0.5, args=(Enrgy_targ, log10numin, log10numax, log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0))



def Bmax_func(log10BNS, Enrgy_targ, log10numin, log10numax,  z, MBH, MNS, spin_parm, asep, OmNS,r0):
    return EgyFreqFluxAPRX(log10numin, log10numax, z, log10BNS, MBH, MNS, spin_parm, asep, OmNS,r0) - Enrgy_targ


def Bmax_apx(Enrgy_targ, log10numin, log10numax,  z, MBH, MNS, spin_parm, asep, OmNS, r0):
    #return opt.brentq(Bmax_func, 12., 16.5, args=(Enrgy_targ, log10numin, log10numax,  z, MBH, MNS, spin_parm, asep, OmNS,r0))
    #return opt.brentq(Bmax_func, 11., 16., args=(Enrgy_targ, log10numin, log10numax,  z, MBH, MNS, spin_parm, asep, OmNS,r0))
    ##with 1+z in eearg and DL
    #return opt.brentq(Bmax_func, 13.7, 17.0, args=(Enrgy_targ, log10numin, log10numax,  z, MBH, MNS, spin_parm, asep, OmNS,r0))
    ### For Var params
    #return opt.brentq(Bmax_func, 13.85, 17.1, args=(Enrgy_targ, log10numin, log10numax,  z, MBH, MNS, spin_parm, asep, OmNS,r0))
    ### For Bmax Plots
    return opt.brentq(Bmax_func, 12., 16.5, args=(Enrgy_targ, log10numin, log10numax,  z, MBH, MNS, spin_parm, asep, OmNS,r0))




# ##############################
# ### Disruption?
# ##############################
## is RTid > RH
def RTid(MBH, MNS, RNS):
    return (MBH/MNS)**(1./3.) * RNS


def SDisrupt_fnc(spin_parm, MBH, MNS, RNS):
    return RTid(MBH, MNS, RNS) - RH(MBH, spin_parm)

def SDisrupt(MBH, MNS, RNS):
    try:
        res = opt.brentq(SDisrupt_fnc, 0.0, 1.0, args=(MBH, MNS, RNS))
    except:
        res = -0.01
    return res






# ##############################
# ### Disruption - from Foucart
# ##############################
def tRISCO(SBH):
    # Z1 = 1.+(1.-SBH**2)**(1./3.) * ( (1.+SBH**2)**(1./3.) + (1.-SBH**2)**(1./3.) )
    Z1 = 1.+(1.-SBH**2)**(1./3.) * ( (1.+SBH)**(1./3.) + (1.-SBH)**(1./3.) )
    Z2 = np.sqrt(3.*SBH**2 + Z1**2)
    return 3. + Z2 - np.sign(SBH) * np.sqrt((3.-Z1)*(3. + Z1 + 2.*Z2)) 
   # return tRISCO in units of GMBH/c^2


def MremEq4_Foucart(SBH, MBH, MNS, RNS):
    CNS = G*MNS/(c**2*RNS)
    QQ = MBH/MNS ## opp of q
    qs = QQ/(1.+QQ)**2
    alp = 0.406
    bet = 0.139
    gam = 0.255
    dlt = 1.761
    Mrema = alp*(1.-2.*CNS)/qs**(1./3.) - bet*tRISCO(SBH)*CNS/qs + gam
    #Mremb = max(Mrema, 0.0)
    #return Mremb**(dlt)
    return Mrema#**(dlt) ## just to get where it is zero


def Sdis_FoucM0(MBH, MNS, RNS):
    try:
        res = opt.brentq(MremEq4_Foucart, -1.0, 1.0, args=(MBH, MNS, RNS))
    except:
        res = np.sqrt(-1.0)
    return res


def Sdis_FoucMF_fnc(SBH, Frac, MBH, MNS, RNS):
    return MremEq4_Foucart(SBH, MBH, MNS, RNS) - Frac

def Sdis_FoucMF(Frac, MBH, MNS, RNS):
    try:
        res = opt.brentq(Sdis_FoucMF_fnc, -1.0, 1.0, args=(Frac, MBH, MNS, RNS))
    except:
        res = np.sqrt(-1.0)
    return res


# ##############################
# ##############################
# ### DIAGNOSTICS
# ##############################
# ##############################
# #mathematica - to make checks match better in that notebook
# # c = 2.9979*10**(10)
# # G = 6.673*10**(-8)
# # Msun = 2.*10.**33


# ztst=0.06
# spin_parm=1.0
# MBH=10*Msun
# MNS=1.4*Msun
# OmNS = 2.*np.pi/1.0
# rr0=1.0*G*MBH/c**2
# Rphot_tst = 46.6*rr0
# log10BNS_tst=14
# nu_tst = 10**18

# GBMnumin = 0.008*10**6 * eVperErg/hplnk
# GBMnumax = 30.*10**6   * eVperErg/hplnk
# log10numin = np.log10(GBMnumin)
# log10numax = np.log10(GBMnumax)

# Flx_UL = 10.*10.**(-7)


# lum = Pow_supply(10**log10BNS_tst, MBH, MNS, spin_parm, rr0, OmNS)

# gamtst = GamQuick(log10BNS_tst, MBH, MNS, spin_parm, rr0, OmNS)

# KT_tst = KTExpR(Rphot_tst, log10BNS_tst, MBH, MNS, spin_parm, rr0, OmNS)

# Rphot = Rph(log10BNS_tst, MBH, MNS, spin_parm, rr0, OmNS)

# tst = E_REl_BB_APRX(18., Rphot_tst, ztst, log10BNS_tst, MBH, MNS, spin_parm, rr0, OmNS)
# #tst = E_REl_BB_APRX(GBMnumin, Rphot_tst, z, log10BNS_tst, MBH, MNS, spin_parm, rr0, OmNS)

# print("Integral time")
# flx = EgyFreqFluxAPRX(log10numin,log10numax, ztst, log10BNS_tst, MBH, MNS, spin_parm, rr0, OmNS)
# #flx = EgyFreqFluxAPRX_z(GBMnumin,GBMnumax, log10BNS_tst, MBH, MNS, spin_parm, rr0, OmNS)

# print("Solve for zmax")
# zmx = Zmax(Flx_UL, log10numin, log10numax, log10BNS_tst, MBH, MNS, spin_parm, rr0, OmNS)

# print("Solve for Bmax")
# ztst = 0.001
# Bmx = Bmax_apx(Flx_UL, log10numin, log10numax, ztst, MBH, MNS, spin_parm, rr0, OmNS)








import numpy as np

import matplotlib.pyplot as plt
import scipy.stats as stats


def Gauss_2D(x, y, mux, muy, sigx, sigy):
	Gx = -0.5*(x-mux)**2/sigx**2
	Gy = -0.5*(y-muy)**2/sigy**2
	return 1./(2.*np.pi * sigx * sigy) * np.exp(Gx + Gy)

def Gauss_1D(x, mux, sigx):
	Gx = -0.5*(x-mux)**2/sigx**2
	return 1./(np.sqrt(2.*np.pi) * sigx) * np.exp(Gx)



mux = 0.0
muy = 0.0
sigx = 1.0
sigy = 1.1

# stats.norm.cdf(0.49)

sig1x = stats.norm.interval(0.68, loc=mux, scale=sigx)
NinCnfx = stats.norm.interval(0.90, loc=mux, scale=sigx)
sig2x = stats.norm.interval(0.95, loc=mux, scale=sigx)

sig1y = stats.norm.interval(0.68, loc=muy, scale=sigy)
NinCnfy = stats.norm.interval(0.90, loc=muy, scale=sigy)
sig2y = stats.norm.interval(0.95, loc=muy, scale=sigy)

sig1x_cont = stats.norm.pdf(sig1x[1], loc=mux, scale=sigx)
NinCnfx_cont = stats.norm.pdf(NinCnfx[1], loc=mux, scale=sigx)
sig2x_cont = stats.norm.pdf(sig2x[1], loc=mux, scale=sigx)

sig1y_cont = stats.norm.pdf(sig1y[1], loc=muy, scale=sigy)
NinCnfy_cont = stats.norm.pdf(NinCnfy[1], loc=muy, scale=sigy)
sig2y_cont = stats.norm.pdf(sig2y[1], loc=muy, scale=sigy)



Ngrd = 100
xs =  np.linspace(-3,3.,Ngrd)
ys =  np.linspace(-3,3.,Ngrd)



G2d = np.zeros([Ngrd,Ngrd])
for i in range(Ngrd):
	for j in range(Ngrd):
		G2d[j][i] = Gauss_2D(xs[i], ys[j], mux, muy, sigx, sigy)

plt.figure()
# plt.contourf(xs, ys, G2d)
plt.contour(xs,ys, G2d, levels=[sig2x_cont, NinCnfx_cont, sig1x_cont], colors='black')
plt.contour(xs,ys, G2d, levels=[sig2y_cont, NinCnfy_cont, sig1y_cont], linestyles='--', colors='red')
plt.show()




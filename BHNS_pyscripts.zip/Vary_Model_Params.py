import numpy as np
import scipy as sc
import matplotlib
#matplotlib.use('Agg')

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
matplotlib.rcParams['font.family'] = 'sans-serif'
matplotlib.rcParams['font.sans-serif'] = ['Helvetica']
matplotlib.rcParams.update({'font.size': 16})
import matplotlib.pyplot as plt

plt.rcParams.update({
    "text.usetex": True,
    "font.family": "sans-serif",
    "font.sans-serif": ["Helvetica"]})



import Bmax_Flux_integral_funcs as bmxflx
import BHNSpow_funcs as Pwf


class nf(float):
    def __repr__(self):
        s = f'{self:.1f}'
        return f'{self:.0f}' if s[-1] == '0' else s



################################################
#Physical Constants
################################################
G    = 6.67384*10.**(-8)
c    = 2.99792458*10.**(10)
Msun = 1.989*10.**33
day2sec = 24.*3600.
day2yr = 1./365.25
yr2sec = 3.154*10.**7
pc2cms = 3.08567758*10**(18)
Mpcs = 10**6*pc2cms
eVperErg = 1./6.242e+11

hplnk = 6.62607*10**(-27) ##(*Planks constant (erg * s)  *)
kb = 1.3807*10**(-16)
me = 9.109*10**(-28)
sigT = 6.652*10**(-25) #(*Thompson scattering cross section 
sigSB = 5.670*10**(-5) #Stef Boltz


hub = 0.679 # 0.7  
Om = 0.3065#0.3
OL = 1.0-Om #0.7



################################################

def yErrEll(x, mux, muy, sigx, sigy):
    XX = ((x-mux)/sigx)**2
    slnp = sigy*np.sqrt(1.-XX) + muy
    slnm = -sigy*np.sqrt(1.-XX) + muy
    return [slnp, slnm]

################################################

################################################
# wchcase = "optim"
#wchcase = "pesim"
################################################
###FERMI UPPER LIMITS FROM GCN
### GW200105 (bigger BHmass) -- 82% of localizaiton zone covered
# if (wchcase=="pesim"):
#     whichUL = 'Hard-Short'
#     whichSPn = "SBHmin"
# elif (wchcase=="optim"):

################################################
### OPTIONS
################################################
var_asep = True
var_FUL = False
##HAVE TO KEEP THESE CHOICES
whichUL = 'Norm-Mid'
whichSPn = "SBHmax"
NSspin = False
src3 = True ##also plot GW190814 results
################################################



z50 = 0.05754/5.
Dlum50 = bmxflx.DL(z50, hub, Om, OL)

z265=0.05754
Dlum265 = bmxflx.DL(z265, hub, Om, OL)
Dang265 = bmxflx.Dang(z265, hub, Om, OL)
# Dlum265/Mpcs
z331=0.07116
Dlum331 = bmxflx.DL(z331, hub, Om, OL)
Dang331 = bmxflx.Dang(z331, hub, Om, OL)

z276=0.0598
Dlum276 = bmxflx.DL(z276, hub, Om, OL)
Dang276 = bmxflx.Dang(z276, hub, Om, OL)

##alternatively (from Lum at 265 Mpc)
#over 1kev -10 MeV
Hard_short0 = 21.*10**(48) / (4.*np.pi*Dlum265**2) / 10**(-7)
Norm_mid0   = 2.1*10**(48) / (4.*np.pi*Dlum265**2) / 10**(-7)


##alternatively (from Lum at 265 Mpc)
#over 1kev -10 MeV
Hard_short1 = 52.*10**(48) / (4.*np.pi*Dlum331**2) / 10**(-7)
Norm_mid1   = 5.2*10**(48) / (4.*np.pi*Dlum331**2) / 10**(-7)


##alternatively (from Lum at 276 Mpc)
#over 1kev -10 MeV
Hard_short2 = 12.25*10**(48) / (4.*np.pi*Dlum276**2) / 10**(-7)
Norm_mid2   = 1.19*10**(48) / (4.*np.pi*Dlum276**2) / 10**(-7)




if (whichUL == 'Hard-Short'):
    Flx_UL0 = Hard_short0 * 10**(-7)
    Flx_UL1 = Hard_short1 * 10**(-7)
    Flx_UL2 = Hard_short2 * 10**(-7)

elif (whichUL == 'Norm-Mid'):
    Flx_UL0 = Norm_mid0 * 10**(-7)
    Flx_UL1 = Norm_mid1 * 10**(-7)
    Flx_UL2 = Norm_mid2 * 10**(-7)

elif (whichUL == 'Soft-Long'):
    Flx_UL0 = Soft_long0 * 10**(-7)
    Flx_UL1 = Soft_long1 * 10**(-7)
    Flx_UL2 = Soft_long2 * 10**(-7)
else:
    print ("Must Choose an UL")
    sdfdsds


GBMnumin = 0.008*10**6 * eVperErg/hplnk
GBMnumax = 30.*10**6   * eVperErg/hplnk
# log10numin = np.log10(GBMnumin)
# log10numax = np.log10(GBMnumax)

UL_min = 0.001*10**6 * eVperErg/hplnk
UL_max = 10.000*10**6 * eVperErg/hplnk
log10numin = np.log10(UL_min)
log10numax = np.log10(UL_max)

################################################
################################################
###OLDER FERMI min estimate:
# use minimum phot/sec count rate detectable by Fermi and mult by most common photon energy from model to get flux
# can more accurealty compute flux in phot/sec
# charE = 0.24*np.sqrt(BNS/10**12) ##MeV
# FermiMin = 0.5*10**6*eVperErg ##phot/sec * 10^6 eV/phot * erg/ev




################################################
### System params
################################################
# spin_parm = 1.0
if (whichSPn=="SBHmin"):
    spin_parm0 = 0.0 ## GW200105
    spin_parm1 = 0.0 ## GW200115
    spin_parm2 = 0.0 ## GW190814
elif (whichSPn=="SBHmax"):
    # spin_parm0 = 0.30 ## GW200105
    # spin_parm1 = 0.81 ## GW200115
    spin_parm0 = 0.27 ## GW200105
    spin_parm1 = 0.83 ## GW200115
    spin_parm2 = 0.07 ## GW190814
#MNS = 0.5*(1.9+0.2 + 1.4-0.2)*Msun ## average of lower and upper NS mass limits
MNS0 = 1.9*Msun ## GW200105
MNS1 = 1.4*Msun ## GW200115
MNS2 = 2.59*Msun ## GW190814

RNS = 10.**6
if (NSspin):
    OmNS = 2.*np.pi/1.0 #-2.*np.pi/0.001 #1 second spin period 
else:
    OmNS = 0.0


################################################

### DEFs for the CODE
# MNSprint = MNS/Msun
MNS0print = MNS0/Msun
MNS1print = MNS1/Msun
MNS2print = MNS2/Msun








NHRes = 40 #100


zmin = 0.01
zmax = 0.11

zsHR = np.linspace(zmin, zmax, NHRes)
DlumMin = bmxflx.DL(zmin, hub, Om, OL)
DlumMax = bmxflx.DL(zmax, hub, Om, OL)

DLumsHR = bmxflx.DL(zsHR, hub, Om, OL)


################################################
################################################
#GW200105
################################################
################################################

datx = [280, 280]
daty = [8.9, 8.9]

xerrs = [[110,110],[110,110]]
yerrs = [[1.3, 1.3],[1.1, 1.1]]

xmaxs0 = datx[0] + xerrs[1][0]
xmaxs1 = datx[1] + xerrs[1][1]
xmins0 = datx[0] - xerrs[0][0]
xmins1 = datx[1] - xerrs[0][1]
xmaxs = [xmaxs0, xmaxs1]

ymaxs0 = daty[0] + yerrs[1][0]
ymaxs1 = daty[1] + yerrs[1][1]
ymins0 = daty[0] - yerrs[0][0]
ymins1 = daty[1] - yerrs[0][1]
ymaxs = [ymaxs0, ymaxs1]


##############################
### Get the Upper limit for B on the error ellipse
##############################
zUL0 = bmxflx.DLtoZ(xmaxs0*Mpcs)
DLums_hlv = np.linspace(datx[0], 500., NHRes)

#MBH values on the error ellipse
erlipseplt = yErrEll(DLums_hlv , datx[0], daty[0], xerrs[1][0], yerrs[1][0])[0]
MBH_erlipsep, MBH_erlipsem = yErrEll(DLumsHR/Mpcs, datx[0], daty[0], xerrs[1][0], yerrs[1][0])

BNS_ellpses0 = np.zeros(NHRes)
for i in range(NHRes):
    asepmins0 = bmxflx.asepmin(RNS, MBH_erlipsep[i]*Msun, spin_parm0) + RNS
    r0s0 = 0.5*asepmins0
    BNS_ellpses0[i] = bmxflx.Bmax_apx(Flx_UL0, log10numin, log10numax, zsHR[i], MBH_erlipsep[i]*Msun, MNS0, spin_parm0, asepmins0, OmNS, r0s0)

iUL0 = np.argmax(BNS_ellpses0)
MBH_UL0 = MBH_erlipsep[iUL0]
zs_UL0 = zsHR[iUL0]
DL_UL0 = bmxflx.DL(zs_UL0, hub, Om, OL)

asepmin_crit0_BEST = bmxflx.asepmin(RNS, MBH_UL0*Msun, spin_parm0) + RNS
r0_crit0_BEST = 0.5*asepmin_crit0_BEST

asepmin_crit0_WRST = bmxflx.asepmin(RNS, MBH_UL0*Msun, 0.0) + RNS
r0_crit0_WRST = 0.5*asepmin_crit0_WRST

#BNS_upper_lim0 = bmxflx.Bmax_apx(Flx_UL0, log10numin, log10numax, zs_UL0 , MBH_UL0*Msun, MNS0, spin_parm0, asepmin_crit0, OmNS, r0_crit0)
##############################
##############################





##############################
##############################
#GW200115
##############################
##############################
datx = [310, 310]
daty = [5.9, 5.9]

xerrs = [[110,110],[150,150]]
yerrs = [[2.1, 2.1],[1.4, 1.4]]

xmaxs0 = datx[0] + xerrs[1][0]
xmaxs1 = datx[1] + xerrs[1][1]
xmins0 = datx[0] - xerrs[0][0]
xmins1 = datx[1] - xerrs[0][1]
xmaxs = [xmaxs0, xmaxs1]

ymaxs0 = daty[0] + yerrs[1][0]
ymaxs1 = daty[1] + yerrs[1][1]
ymins0 = daty[0] - yerrs[0][0]
ymins1 = daty[1] - yerrs[0][1]
ymaxs = [ymaxs0, ymaxs1]

zUL1 = bmxflx.DLtoZ(xmaxs1*Mpcs)


##############################
### Get the Upper limit for B on the error ellipse
##############################
#BNS_upper_lim1 = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zUL1, ymaxs1*Msun, MNS1, spin_parm1, bmxflx.asepmin(RNS, ymaxs1*Msun, spin_parm1), OmNS)
#BNS_upper_lim1 = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zUL1, ymaxs1*Msun, MNS1, spin_parm, Pwf.RH(ymaxs1*Msun, spin_parm), OmNS)
DLums_hlv = np.linspace(datx[0], 500., NHRes)
#MBH values on the error ellipse
erlipseplt = yErrEll(DLums_hlv , datx[0], daty[0], xerrs[1][0], yerrs[1][0])[0]
MBH_erlipsep, MBH_erlipsem = yErrEll(DLumsHR/Mpcs, datx[0], daty[0], xerrs[1][0], yerrs[1][0])

BNS_ellpses1 = np.zeros(NHRes)
for i in range(NHRes):
    asepmins1 = bmxflx.asepmin(RNS, MBH_erlipsep[i]*Msun, spin_parm1) + RNS
    r0s1 = 0.5*asepmins1
    BNS_ellpses1[i] = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zsHR[i], MBH_erlipsep[i]*Msun, MNS1, spin_parm1, asepmins1, OmNS, r0s1)

iUL1 = np.argmax(BNS_ellpses1)
MBH_UL1 = MBH_erlipsep[iUL1]
zs_UL1 = zsHR[iUL1]
DL_UL1 = bmxflx.DL(zs_UL1, hub, Om, OL)

asepmin_crit1_BEST = bmxflx.asepmin(RNS, MBH_UL1*Msun, spin_parm1) + RNS
r0_crit1_BEST = 0.5*asepmin_crit1_BEST

asepmin_crit1_WRST = bmxflx.asepmin(RNS, MBH_UL1*Msun, 0.0) + RNS
r0_crit1_WRST = 0.5*asepmin_crit1_WRST

#BNS_upper_lim1 = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zs_UL1 , MBH_UL1*Msun, MNS1, spin_parm1, asepmin_crit1, OmNS, r0_crit1)
##############################
##############################



if (src3):
	##############################
	##############################
	#GW190814
	##############################
	##############################
	datx = [241, 241]
	daty = [23.1, 23.1]

	xerrs = [[41,41],[45,45]]
	yerrs = [[1.1, 1.1],[1.0, 1.0]]

	xmaxs0 = datx[0] + xerrs[1][0]
	xmaxs1 = datx[1] + xerrs[1][1]
	xmins0 = datx[0] - xerrs[0][0]
	xmins1 = datx[1] - xerrs[0][1]
	xmaxs = [xmaxs0, xmaxs1]

	ymaxs0 = daty[0] + yerrs[1][0]
	ymaxs1 = daty[1] + yerrs[1][1]
	ymins0 = daty[0] - yerrs[0][0]
	ymins1 = daty[1] - yerrs[0][1]
	ymaxs = [ymaxs0, ymaxs1]

	zUL2 = bmxflx.DLtoZ(xmaxs1*Mpcs)


	##############################
	### Get the Upper limit for B on the error ellipse
	##############################
	#BNS_upper_lim1 = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zUL1, ymaxs1*Msun, MNS1, spin_parm1, bmxflx.asepmin(RNS, ymaxs1*Msun, spin_parm1), OmNS)
	#BNS_upper_lim1 = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zUL1, ymaxs1*Msun, MNS1, spin_parm, Pwf.RH(ymaxs1*Msun, spin_parm), OmNS)
	DLums_hlv = np.linspace(datx[0], 500., NHRes)
	#MBH values on the error ellipse
	erlipseplt = yErrEll(DLums_hlv , datx[0], daty[0], xerrs[1][0], yerrs[1][0])[0]
	MBH_erlipsep, MBH_erlipsem = yErrEll(DLumsHR/Mpcs, datx[0], daty[0], xerrs[1][0], yerrs[1][0])

	BNS_ellpses2 = np.zeros(NHRes)
	for i in range(NHRes):
	    asepmins2 = bmxflx.asepmin(RNS, MBH_erlipsep[i]*Msun, spin_parm2) + RNS
	    r0s2 = 0.5*asepmins2
	    BNS_ellpses2[i] = bmxflx.Bmax_apx(Flx_UL2, log10numin, log10numax, zsHR[i], MBH_erlipsep[i]*Msun, MNS2, spin_parm2, asepmins2, OmNS, r0s2)

	iUL2= np.argmax(BNS_ellpses2)
	MBH_UL2 = MBH_erlipsep[iUL2]
	zs_UL2 = zsHR[iUL2]
	DL_UL2 = bmxflx.DL(zs_UL2, hub, Om, OL)

	asepmin_crit2_BEST = bmxflx.asepmin(RNS, MBH_UL2*Msun, spin_parm2) + RNS
	r0_crit2_BEST = 0.5*asepmin_crit2_BEST

	asepmin_crit2_WRST = bmxflx.asepmin(RNS, MBH_UL2*Msun, 0.0) + RNS
	r0_crit2_WRST = 0.5*asepmin_crit2_WRST

	#BNS_upper_lim1 = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zs_UL1 , MBH_UL1*Msun, MNS1, spin_parm1, asepmin_crit1, OmNS, r0_crit1)
	##############################
	##############################




# Nprm = 40
# rgUL1 = (G*MBH_UL1*Msun/c**2)
# r0_min = 1.0 #G*MBH_UL*Msun/c**2
# r0_max1 = 2.*asepmin_crit1/rgUL1
# r0_Var1 = np.linspace(r0_min, r0_max1, Nprm)

# BNS_upper1_rFB0s = np.zeros(Nprm)
# for i in range(Nprm):
# 	BNS_upper1_rFB0s[i] = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zs_UL1 , MBH_UL1*Msun, MNS1, spin_parm1, asepmin_crit1, OmNS, r0_Var1[i]*rgUL1)




Nprm = 100
rgUL0 = (G*MBH_UL0*Msun/c**2)
asep_min0_BEST =  (asepmin_crit0_BEST - RNS)  
asep_min0_WRST =  (asepmin_crit0_WRST - RNS)  ##   = RH 
asep_max0 = 6.*rgUL0 
asep_Var0_BEST = np.linspace(asep_min0_BEST, asep_max0, Nprm)
asep_Var0_WRST = np.linspace(asep_min0_WRST, asep_max0, Nprm)


rgUL1 = (G*MBH_UL1*Msun/c**2)
asep_min1_BEST =  (asepmin_crit1_BEST - RNS)  ## the numerator  = RH 
asep_min1_WRST =  (asepmin_crit1_WRST - RNS)  ## the numerator  = RH 
asep_max1 = 6.*rgUL1 
asep_Var1_BEST = np.linspace(asep_min1_BEST, asep_max1, Nprm)
asep_Var1_WRST = np.linspace(asep_min1_WRST, asep_max1, Nprm)

#Smallest to largest
asep_var0 = np.linspace(2.*rgUL0, 6.*rgUL0, Nprm)
asep_var1 = np.linspace(2.*rgUL1, 6.*rgUL1, Nprm)


if (src3):
	rgUL2 = (G*MBH_UL2*Msun/c**2)
	asep_min2_BEST =  (asepmin_crit2_BEST - RNS)  ## the numerator  = RH 
	asep_min2_WRST =  (asepmin_crit2_WRST - RNS)  ## the numerator  = RH 
	asep_max2 = 6.*rgUL2
	asep_Var2_BEST = np.linspace(asep_min2_BEST, asep_max2, Nprm)
	asep_Var2_WRST = np.linspace(asep_min2_WRST, asep_max2, Nprm)

	asep_var2 = np.linspace(2.*rgUL2, 6.*rgUL2, Nprm)







BNS_upper0_aseps_BEST = np.zeros(Nprm)
BNS_upper1_aseps_BEST = np.zeros(Nprm)
BNS_upper2_aseps_BEST = np.zeros(Nprm)

BNS_upper0_aseps_WRST = np.zeros(Nprm)
BNS_upper1_aseps_WRST = np.zeros(Nprm)
BNS_upper2_aseps_WRST = np.zeros(Nprm)



Fill0_Lo = np.zeros(Nprm)
Fill0_Hi = np.zeros(Nprm)

Fill1_Lo = np.zeros(Nprm)
Fill1_Hi = np.zeros(Nprm)

Fill2_Lo = np.zeros(Nprm)
Fill2_Hi = np.zeros(Nprm)

if (var_asep):
## assumes we are always chooing Nomr-mid Spinmax mode as default
	for i in range(Nprm):
		BNS_upper0_aseps_BEST[i] = bmxflx.Bmax_apx(Flx_UL0,     log10numin, log10numax, zs_UL0 , MBH_UL0*Msun, MNS0, spin_parm0, asep_Var0_BEST[i], OmNS, 0.5*asep_Var0_BEST[i])
		BNS_upper0_aseps_WRST[i] = bmxflx.Bmax_apx(Flx_UL0*10., log10numin, log10numax, zs_UL0 , MBH_UL0*Msun, MNS0, 0.0,        asep_Var0_WRST[i], OmNS, 0.5*asep_Var0_WRST[i])
		BNS_upper1_aseps_BEST[i] = bmxflx.Bmax_apx(Flx_UL1,     log10numin, log10numax, zs_UL1 , MBH_UL1*Msun, MNS1, spin_parm1, asep_Var1_BEST[i], OmNS, 0.5*asep_Var1_BEST[i])
		BNS_upper1_aseps_WRST[i] = bmxflx.Bmax_apx(Flx_UL1*10., log10numin, log10numax, zs_UL1 , MBH_UL1*Msun, MNS1, 0.0,        asep_Var1_WRST[i], OmNS, 0.5*asep_Var1_WRST[i])
	# for i in range(Nprm):
		Fill0_Lo[i] = bmxflx.Bmax_apx(Flx_UL0,     log10numin, log10numax, zs_UL0 , MBH_UL0*Msun, MNS0, spin_parm0, asep_var0[i], OmNS, 0.5*asep_var0[i])
		Fill0_Hi[i] = bmxflx.Bmax_apx(Flx_UL0*10., log10numin, log10numax, zs_UL0 , MBH_UL0*Msun, MNS0, 0.0,        asep_var0[i], OmNS, 0.5*asep_var0[i])
		Fill1_Lo[i] = bmxflx.Bmax_apx(Flx_UL1,     log10numin, log10numax, zs_UL1 , MBH_UL1*Msun, MNS1, spin_parm1, asep_var1[i], OmNS, 0.5*asep_var1[i])
		Fill1_Hi[i] = bmxflx.Bmax_apx(Flx_UL1*10., log10numin, log10numax, zs_UL1 , MBH_UL1*Msun, MNS1, 0.0,        asep_var1[i], OmNS, 0.5*asep_var1[i])
		if (src3):
			BNS_upper2_aseps_BEST[i] = bmxflx.Bmax_apx(Flx_UL2,     log10numin, log10numax, zs_UL2 , MBH_UL2*Msun, MNS2, spin_parm2, asep_Var2_BEST[i], OmNS, 0.5*asep_Var2_BEST[i])
			BNS_upper2_aseps_WRST[i] = bmxflx.Bmax_apx(Flx_UL2*10., log10numin, log10numax, zs_UL2 , MBH_UL2*Msun, MNS2, 0.0,        asep_Var2_WRST[i], OmNS, 0.5*asep_Var2_WRST[i])
			
			Fill2_Lo[i] = bmxflx.Bmax_apx(Flx_UL2,     log10numin, log10numax, zs_UL2 , MBH_UL2*Msun, MNS2, spin_parm2, asep_var2[i], OmNS, 0.5*asep_var2[i])
			Fill2_Hi[i] = bmxflx.Bmax_apx(Flx_UL2*10., log10numin, log10numax, zs_UL2 , MBH_UL2*Msun, MNS2, 0.0,        asep_var2[i], OmNS, 0.5*asep_var2[i])





	x_fidB0 = (asepmin_crit0_BEST)
	x_fidB1 = (asepmin_crit1_BEST)

	x_fidW0 = (asepmin_crit0_WRST)
	x_fidW1 = (asepmin_crit1_WRST)

	y_fidB0 = bmxflx.Bmax_apx(Flx_UL0, log10numin, log10numax, zs_UL0 , MBH_UL0*Msun, MNS0, spin_parm0, x_fidB0, OmNS, 0.5*x_fidB0)
	y_fidB1 = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zs_UL1 , MBH_UL1*Msun, MNS1, spin_parm1, x_fidB1, OmNS, 0.5*x_fidB1)

	y_fidW0 = bmxflx.Bmax_apx(Flx_UL0*10., log10numin, log10numax, zs_UL0 , MBH_UL0*Msun, MNS0, 0.0, x_fidW0, OmNS, 0.5*x_fidW0)
	y_fidW1 = bmxflx.Bmax_apx(Flx_UL1*10., log10numin, log10numax, zs_UL1 , MBH_UL1*Msun, MNS1, 0.0, x_fidW1, OmNS, 0.5*x_fidW1)


	if (src3):
		x_fidB2 = (asepmin_crit2_BEST)
		x_fidW2 = (asepmin_crit2_WRST)
		y_fidB2 = bmxflx.Bmax_apx(Flx_UL2,     log10numin, log10numax, zs_UL2 , MBH_UL2*Msun, MNS2, spin_parm2, x_fidB2, OmNS, 0.5*x_fidB2)
		y_fidW2 = bmxflx.Bmax_apx(Flx_UL2*10., log10numin, log10numax, zs_UL2 , MBH_UL2*Msun, MNS2, 0.0,        x_fidW2, OmNS, 0.5*x_fidW2)





	# plt.figure()
	# plt.plot(r0_Var1, BNS_upper1_rFB0s)
	# plt.show()

	#NOt Quite, the best case is not actualyl the best case becaus of spin issues
	#wherearr = np.where()


	

plt.figure()


plt.plot(asep_Var0_BEST/rgUL0, BNS_upper0_aseps_BEST, color='teal')
plt.plot(asep_Var0_WRST/rgUL0, BNS_upper0_aseps_WRST, color='teal', linestyle="--")

plt.plot(asep_Var1_BEST/rgUL1, BNS_upper1_aseps_BEST, color='#d95f0e')#, linestyle='--')
plt.plot(asep_Var1_WRST/rgUL1, BNS_upper1_aseps_WRST, color='#d95f0e', linestyle='--')
                               #BNS_upper1_aseps_WRST

##BEST starts at smallest x value, both end at same high x
fb0 = plt.fill_between(asep_var0/rgUL0, Fill0_Lo, Fill0_Hi, alpha=0.5, color='teal')
fb1 = plt.fill_between(asep_var1/rgUL1, Fill1_Lo, Fill1_Hi, alpha=0.5, color='#d95f0e')

dtst = plt.scatter(x_fidB0/rgUL0, y_fidB0, color='teal', zorder=25, edgecolors='k')
plt.scatter(x_fidW0/rgUL0, y_fidW0, color='teal', zorder=25, edgecolors='k')

dtso = plt.scatter(x_fidB1/rgUL1, y_fidB1, color='#d95f0e', zorder=25, edgecolors='k')
plt.scatter(x_fidW1/rgUL1, y_fidW1, color='#d95f0e', zorder=25, edgecolors='k')

if (src3):
	plt.plot(asep_Var2_BEST/rgUL2, BNS_upper2_aseps_BEST, color='chartreuse')#, linestyle='--')
	plt.plot(asep_Var2_WRST/rgUL2, BNS_upper2_aseps_WRST, color='chartreuse', linestyle='--')
#
	fb2 = plt.fill_between(asep_var2/rgUL2, Fill2_Lo, Fill2_Hi, alpha=0.4, color='chartreuse')
#
	plt.scatter(x_fidB2/rgUL2, y_fidB2, color='chartreuse', zorder=25, edgecolors='k')
	plt.scatter(x_fidW2/rgUL2, y_fidW2, color='chartreuse', zorder=25, edgecolors='k')


# plt.axvline((asepmin_crit0_BEST)/rgUL0, color='teal', linestyle="-")
# plt.axvline((asepmin_crit1_BEST)/rgUL1, color='orange', linestyle="-")
# plt.axvline((asepmin_crit0_WRST)/rgUL0, color='teal', linestyle="--")
# plt.axvline((asepmin_crit1_WRST)/rgUL1, color='orange', linestyle="--")

plt.xlabel(r'$r_{\mathrm{mrg}}/r_{\mathrm{G},i}$')
plt.ylabel(r'$\log_{10}B_{\mathrm{max}}[\mathrm{G}]$')

#if (src3):
plt.figlegend((fb0,fb1,fb2,dtst),('GW200105', 'GW200115', 'GW190814', 'Fid. Cases'), (0.16,0.71), fontsize=13)
#else:
	# plt.figlegend((fb0,fb1),('GW200105', 'GW200115'), (0.16,0.82), fontsize=13)
#	plt.figlegend((fb0,fb1, dtso),('GW200105', 'GW200115', 'Fid. Cases'), (0.16,0.77), fontsize=13)

plt.tight_layout()

if (src3):
	plt.savefig("Bmax_vs_rmrg_src3.pdf")
else:
	plt.savefig("Bmax_vs_rmrg.pdf")

plt.show()









FULs = np.linspace(0.01, 10., Nprm)
BNS_FLs0 = np.zeros(Nprm)

if (var_FUL):
	for i in range(Nprm):
		#at 50 Mpc
		BNS_FLs0[i] = bmxflx.Bmax_apx(FULs[i]*1.e-7,     log10numin, log10numax, z50, MBH_UL0*Msun, MNS0, 0.0, (2.*rgUL0+RNS), OmNS, 0.5*(2.*rgUL0+RNS))


plt.figure()
plt.plot(np.log10(FULs), BNS_FLs0)
#plt.plot(FULs, BNS_FLs0)
plt.show()











import numpy as np
import scipy as sc
import matplotlib
#matplotlib.use('Agg')

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
matplotlib.rcParams['font.family'] = 'sans-serif'
matplotlib.rcParams['font.sans-serif'] = ['Helvetica']
matplotlib.rcParams.update({'font.size': 16})
import matplotlib.pyplot as plt

plt.rcParams.update({
    "text.usetex": True,
    "font.family": "sans-serif",
    "font.sans-serif": ["Helvetica"]})



import Bmax_Flux_integral_funcs as bmxflx
import BHNSpow_funcs as Pwf


class nf(float):
    def __repr__(self):
        s = f'{self:.1f}'
        return f'{self:.0f}' if s[-1] == '0' else s


################################################
####OPTIONS
################################################
## rcontour grid resolution 
Ngrd =  40
wchcase = "optim"
#wchcase = "pesim"
MandelSmith = False ## use MBH = 70+-0.4 and 0 BHspin and MNS=1.25 as per https://arxiv.org/pdf/2109.14759.pdf
NSspin = False
Spncheck = False
################################################


################################################
#Physical Constants
################################################
G    = 6.67384*10.**(-8)
c    = 2.99792458*10.**(10)
Msun = 1.989*10.**33
day2sec = 24.*3600.
day2yr = 1./365.25
yr2sec = 3.154*10.**7
pc2cms = 3.08567758*10**(18)
Mpcs = 10**6*pc2cms
eVperErg = 1./6.242e+11

hplnk = 6.62607*10**(-27) ##(*Planks constant (erg * s)  *)
kb = 1.3807*10**(-16)
me = 9.109*10**(-28)
sigT = 6.652*10**(-25) #(*Thompson scattering cross section 
sigSB = 5.670*10**(-5) #Stef Boltz


hub = 0.679 # 0.7  
Om = 0.3065#0.3
OL = 1.0-Om #0.7
################################################


################################################
def yErrEll(x, mux, muy, sigx, sigy):
    XX = ((x-mux)/sigx)**2
    slnp = sigy*np.sqrt(1.-XX) + muy
    slnm = -sigy*np.sqrt(1.-XX) + muy
    return [slnp, slnm]

################################################

#FERMI CHECK -- compare inferred flux UL with teh inferred Lum DL at assuemd 265 Mpc
#Note FLux is over 10-1000kev
#Lum is over 1keV to MeV
z265=0.05754
Dlum265 = bmxflx.DL(z265, hub, Om, OL)
Dang265 = bmxflx.Dang(z265, hub, Om, OL)
# Dlum265/Mpcs
z331=0.07116
Dlum331 = bmxflx.DL(z331, hub, Om, OL)
Dang331 = bmxflx.Dang(z331, hub, Om, OL)

z276=0.0598
Dlum276 = bmxflx.DL(z276, hub, Om, OL)
Dang276 = bmxflx.Dang(z276, hub, Om, OL)


# INTEGRAL excess:
# 19.7*10**48/(4.*np.pi*Dlum265**2) / (1.e-7)
# 23.458

# 21.*10**48/(4.*np.pi*Dlum265**2) / (11.*10**(-7))
# #2.3

# 7.5*10**48/(4.*np.pi*Dlum265**2) / (6.3*10**(-7))
# #1.4

# 5.1*10**48/(4.*np.pi*Dlum265**2) / (4.0*10**(-7))
# #1.5


# 8.6*10**48/(4.*np.pi*Dlum265**2) / (4.4*10**(-7))

# 2.1*10**48/(4.*np.pi*Dlum265**2) / (1.8*10**(-7))

# 1.4*10**48/(4.*np.pi*Dlum265**2) / (1.1*10**(-7))


# 2.5*10**48/(4.*np.pi*Dlum265**2) / (1.3*10**(-7))

# 0.75*10**48/(4.*np.pi*Dlum265**2) / (0.63*10**(-7))

# 0.51*10**48/(4.*np.pi*Dlum265**2) / (0.4*10**(-7))

# ################################################
# ## rcontour grid resolution
# Ngrd =  10
# #wchcase = "optim"
# wchcase = "pesim"
# MandelSmith = False ## use MBH = 70+-0.4 and 0 BHspin and MNS=1.25 as per https://arxiv.org/pdf/2109.14759.pdf
# NSspin = False
# Spncheck = False
# ################################################
###FERMI UPPER LIMITS FROM GCN
### GW200105 (bigger BHmass) -- 82% of localizaiton zone covered
if (wchcase=="pesim"):
    whichUL = 'Hard-Short'
    whichSPn = "SBHmin"
elif (wchcase=="optim"):
    whichUL = 'Norm-Mid'
    whichSPn = "SBHmax"

if (Spncheck):
    whichUL = 'Norm-Mid'

##########################
# ### GW200105
##########################
#whicihUL = 'Soft_long0'
#over 10 kev -1 MeV
# 3 sigma flux upper limits over 10-1000 keV, weighted by GW localization
# probability (in units of 10^-7 erg/s/cm^2):

# Timescale      Soft     Normal   Hard
# ------------------------------------
# 0.128 s:    4.0    6.3    11
# 1.024 s:    1.1    1.8    4.4
# 8.192 s:    0.40    0.63    1.3

# Hard_short0 = 11. 
# Norm_mid0 = 1.8
# Soft_long0 = 0.4 

##alternatively (from Lum at 265 Mpc)
#over 1kev -10 MeV
# Assuming the median luminosity distance of 265 Mpc from the GW detection,
# we estimate the following intrinsic luminosity upper limits over the 1
# keV-10 MeV energy range (in units of 10^48 erg/s):

# Timescale  Soft     Normal   Hard
# ------------------------------------
# 0.128s:     5.1        7.5    21
# 1.024s:     1.4       2.1    8.6
# 8.192s:    0.51    0.75    2.5

# Then put them into erg/s/cm^2 in units of 10^(-7) as above
# this is multiplied back (*10**(-7)) below in def of Flux_UL

Hard_short0 = 21.*10**(48) / (4.*np.pi*Dlum265**2) / 10**(-7)
Norm_mid0   = 2.1*10**(48) / (4.*np.pi*Dlum265**2) / 10**(-7)





##########################
# ### GW200115 (smaller BHmass)
##########################
# #3 sigma upper limits
# we set the following
# 3 sigma flux upper limits over 10-1000 keV, weighted by GW localization
# probability (in units of 10^-7 erg/s/cm^2):

# Timescale  Soft     Normal   Hard
# ---------------------------------
# 0.128 s:   4.6      8.3      17.
# 1.024 s:   1.5      2.8      6.1
# 8.192 s:   0.5      0.7      2.0

# Hard_short1 = 17. 
# Norm_mid1 = 2.8
# Soft_long1 = 0.5 

##alternatively (from Lum at 265 Mpc)
#over 1kev -10 MeV
# Assuming the median luminosity distance of 331 Mpc from the GW detection,
# we estimate the following intrinsic luminosity upper limits over the 1
# keV-10 MeV energy range (in units of 10^48 erg/s):

# Timescale  Soft     Normal   Hard
# ---------------------------------
# 0.128s:    9.2      15.      52.
# 1.024s:    3.0      5.2      19.
# 8.192s:    0.9      1.3      6.1

Hard_short1 = 52.*10**(48) / (4.*np.pi*Dlum331**2) / 10**(-7)
Norm_mid1   = 5.2*10**(48) / (4.*np.pi*Dlum331**2) / 10**(-7)


##########################
###GW 190814
##########################
# We therefore set upper limits on impulsive gamma-ray emission. Using the representative soft, normal, and hard GRB-like templates described in arXiv:1612.02395, we set the following 3 sigma flux upper limits over 10-1000 keV (in units of 10^-8 erg/s/cm^2):

# Timescale  soft     norm     hard
# --------------------------------------
# 0.128 s:   17.0     31.0     58.0
# 1.024 s:   5.90     9.30     20.0
# 8.192 s:   2.20     3.10     5.68

##alternatively (from Lum at 276 Mpc)
#over 1kev -10 MeV
# Assuming the median luminosity distance of 276 Mpc (z=0.061) from the GW detection, we estimate the following intrinsic luminosity upper limits over the 1 keV-10 MeV energy range (in units of 10^48 erg/s):

# Timescale  soft    norm    hard
# --------------------------------------
# 0.128 s:   2.35    3.98    12.25
# 1.024 s:   0.81    1.19    4.23
# 8.192 s:   0.30    0.40    1.18

Hard_short2 = 12.25*10**(48) / (4.*np.pi*Dlum276**2) / 10**(-7)
Norm_mid2   = 1.19*10**(48) / (4.*np.pi*Dlum276**2) / 10**(-7)





if (whichUL == 'Hard-Short'):
    Flx_UL0 = Hard_short0 * 10**(-7)
    Flx_UL1 = Hard_short1 * 10**(-7)
    Flx_UL2 = Hard_short2 * 10**(-7)

elif (whichUL == 'Norm-Mid'):
    Flx_UL0 = Norm_mid0 * 10**(-7)
    Flx_UL1 = Norm_mid1 * 10**(-7)
    Flx_UL2 = Norm_mid2 * 10**(-7)

elif (whichUL == 'Soft-Long'):
    Flx_UL0 = Soft_long0 * 10**(-7)
    Flx_UL1 = Soft_long1 * 10**(-7)
    Flx_UL2 = Soft_long2 * 10**(-7)
else:
    print ("Must Choose an UL")
    sdfdsds


GBMnumin = 0.008*10**6 * eVperErg/hplnk
GBMnumax = 30.*10**6   * eVperErg/hplnk
# log10numin = np.log10(GBMnumin)
# log10numax = np.log10(GBMnumax)

UL_min = 0.001*10**6 * eVperErg/hplnk
UL_max = 10.000*10**6 * eVperErg/hplnk
log10numin = np.log10(UL_min)
log10numax = np.log10(UL_max)

################################################
################################################
###OLDER FERMI min estimate:
# use minimum phot/sec count rate detectable by Fermi and mult by most common photon energy from model to get flux
# can more accurealty compute flux in phot/sec
# charE = 0.24*np.sqrt(BNS/10**12) ##MeV
# FermiMin = 0.5*10**6*eVperErg ##phot/sec * 10^6 eV/phot * erg/ev




################################################
### System params
################################################
# spin_parm = 1.0
if (whichSPn=="SBHmin"):
    spin_parm0 = 0.0 ## GW200105
    spin_parm1 = 0.0 ## GW200115
elif (whichSPn=="SBHmax"):
    spin_parm0 = 0.27 ## GW200105
    spin_parm1 = 0.83 ## GW200115
    # spin_parm0 = 0.30 ## GW200105 High SPin prior
    # spin_parm1 = 0.81 ## GW200115 High SPin prior
#MNS = 0.5*(1.9+0.2 + 1.4-0.2)*Msun ## average of lower and upper NS mass limits
# MNS0 = (1.9 - 0.2)*Msun ## GW200105
# MNS1 = (1.4 - 0.2)*Msun ## GW200115
# MNS0 = (1.9 + 0.2)*Msun ## GW200105
# MNS1 = (1.4 + 0.6)*Msun ## GW200115
MNS0 = (1.9)*Msun ## GW200105
MNS1 = (1.4)*Msun ## GW200115

if (MandelSmith):
    whichUL += "-MandelSmith"
    spin_parm1 = 0.0
    MNS1 = 1.25*Msun ## GW200115

RNS = 10.**6
if (NSspin):
    OmNS = 2.*np.pi/1.0 #-2.*np.pi/0.001 #1 second spin period 
else:
    OmNS = 0.0

#rr0=1.0*G*MBH/c**2 #binary separation at merger and initial radius of fireball
#Ng0 = 2.0 - spin_parm ##hack for spin=0 or 1 for now #binary separation in untits of MBH at merger and initial radius of fireball



################################################

### DEFs for the CODE
# MNSprint = MNS/Msun
MNS0print = MNS0/Msun
MNS1print = MNS1/Msun



# Ngrd =  10
NHRes = 100 #100
l10BNSs = np.linspace(12,14,Ngrd)
# MBHs = np.linspace(5,15,Ngrd)
MBHs = np.linspace(3,12,Ngrd)
# DLums = np.linspace(40,500, Ngrd)
zmin = 0.002#0.01
zmax = 0.11
zs = np.linspace(zmin, zmax, Ngrd)
zsHR = np.linspace(zmin, zmax, NHRes)
DlumMin = bmxflx.DL(zmin, hub, Om, OL)
DlumMax = bmxflx.DL(zmax, hub, Om, OL)
DLums = bmxflx.DL(zs, hub, Om, OL)
DLumsHR = bmxflx.DL(zsHR, hub, Om, OL)



# rr0s = Ng0*G*MBHs*Msun/c**2

## separation between NS and BH at energy injection. r0 of fireball is taken as asep/2
#asep0s = RNS + Pwf.RH(MBHs*Msun, spin_parm)
#asep0s = bmxflx.asepmin(RNS, MBHs, spin_parm)
asep0s0 = Pwf.RH(MBHs*Msun, spin_parm0)+RNS
asep0s1 = Pwf.RH(MBHs*Msun, spin_parm1)+RNS
## r0 is where fireball starts from, can be diff from asep, fiducia value is r0=asep/2 so that fireball is sphere with diameter r_mrg
# rFBis0 = 0.5*asep0s0
# rFBis1 = 0.5*asep0s1
nr0 = 0.5
rFBis0 = nr0*asep0s0
rFBis1 = nr0*asep0s1



Bmaxs0 = np.zeros([Ngrd,Ngrd])
Bmaxs1 = np.zeros([Ngrd,Ngrd])
for i in range(Ngrd):
    print("%g/%g" %(i, Ngrd))
    for j in range(Ngrd):
        ##use Fermi sens in photons/sec/cm^2
        # Bmaxs0[j][i] = Pwf.Bmax(0.5, DLums[i]*Mpcs, MBHs[j]*Msun, MNS0, spin_parm, RHaseps[j], OmNS)
        # Bmaxs1[j][i] = Pwf.Bmax(0.5, DLums[i]*Mpcs, MBHs[j]*Msun, MNS1, spin_parm, RHaseps[j], OmNS)

        ## use diff upper limits from FERMI GCN erg.s.cm^2         
        Bmaxs0[j][i] = bmxflx.Bmax_apx(Flx_UL0, log10numin, log10numax, zs[i], MBHs[j]*Msun, MNS0, spin_parm0, asep0s0[j], OmNS, rFBis0[j])
        Bmaxs1[j][i] = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zs[i], MBHs[j]*Msun, MNS1, spin_parm1, asep0s1[j], OmNS, rFBis1[j])












print("Plotting")
# gfdgfhdhg


# Label levels with specially formatted floats
if plt.rcParams["text.usetex"]:
    fmt = r'$%r$'
else:
    fmt = '%r'













#GW200105
datx = [280, 280]
daty = [8.9, 8.9]

xerrs = [[110,110],[110,110]]
yerrs = [[1.3, 1.3],[1.1, 1.1]]

xmaxs0 = datx[0] + xerrs[1][0]
xmaxs1 = datx[1] + xerrs[1][1]
xmins0 = datx[0] - xerrs[0][0]
xmins1 = datx[1] - xerrs[0][1]
xmaxs = [xmaxs0, xmaxs1]

ymaxs0 = daty[0] + yerrs[1][0]
ymaxs1 = daty[1] + yerrs[1][1]
ymins0 = daty[0] - yerrs[0][0]
ymins1 = daty[1] - yerrs[0][1]
ymaxs = [ymaxs0, ymaxs1]


##############################
### Get the Upper limit for B on the error ellipse
##############################
zUL0 = bmxflx.DLtoZ(xmaxs0*Mpcs)
#BNS_upper_lim0 = bmxflx.Bmax_apx(Flx_UL0, log10numin, log10numax, zUL0, ymaxs0*Msun, MNS0, spin_parm0, bmxflx.asepmin(RNS, ymaxs0*Msun, spin_parm0), OmNS)
#BNS_upper_lim0 = bmxflx.Bmax_apx(Flx_UL0, log10numin, log10numax, zUL0, ymaxs0*Msun, MNS0, spin_parm, Pwf.RH(ymaxs0*Msun, spin_parm), OmNS)
#BNS_upper_lim0 = bmxflx.Bmax_apx(Flx_UL0, log10numin, log10numax, zUL0, ymaxs0*Msun, MNS0, spin_parm, G*ymaxs0*Msun/c**2/2., OmNS)

DLums_hlv = np.linspace(datx[0], 500., NHRes)
#MBH values on the error ellipse
erlipseplt = yErrEll(DLums_hlv , datx[0], daty[0], xerrs[1][0], yerrs[1][0])[0]
MBH_erlipsep, MBH_erlipsem = yErrEll(DLumsHR/Mpcs, datx[0], daty[0], xerrs[1][0], yerrs[1][0])

BNS_ellpses0 = np.zeros(NHRes)
for i in range(NHRes):
    asepmins0 = bmxflx.asepmin(RNS, MBH_erlipsep[i]*Msun, spin_parm0) + RNS
    r0s0 = nr0*asepmins0
    BNS_ellpses0[i] = bmxflx.Bmax_apx(Flx_UL0, log10numin, log10numax, zsHR[i], MBH_erlipsep[i]*Msun, MNS0, spin_parm0, asepmins0, OmNS, r0s0)

iUL0 = np.argmax(BNS_ellpses0)
MBH_UL0 = MBH_erlipsep[iUL0]
zs_UL0 = zsHR[iUL0]
DL_UL0 = bmxflx.DL(zs_UL0, hub, Om, OL)
asepmin_crit0 = bmxflx.asepmin(RNS, MBH_UL0*Msun, spin_parm0) + RNS
r0_crit0 = nr0*asepmin_crit0
BNS_upper_lim0 = bmxflx.Bmax_apx(Flx_UL0, log10numin, log10numax, zs_UL0 , MBH_UL0*Msun, MNS0, spin_parm0, asepmin_crit0, OmNS, r0_crit0)
##############################
##############################






# these are matplotlib.patch.Patch properties
props = dict(boxstyle='round', facecolor='white', alpha=0.7)



fig, ax = plt.subplots()
#plt.title(r'GW200105; $\log_{10} \left(B_{\max} [\mathrm{Gauss}]\right)$', fontsize=14)

if (wchcase=="optim"):
    plt.title(r'GW200105; $\log_{10} \left(B_{\max} [\mathrm{G}]\right)$; Optimistic', fontsize=14)
else:
    plt.title(r'GW200105; $\log_{10} \left(B_{\max} [\mathrm{G}]\right)$; Pessimistic', fontsize=14)

#CSf = ax.contourf(DLums/Mpcs, MBHs,  Bmaxs0, 100, cmap='viridis_r')
# CS = ax.contour(DLums/Mpcs, MBHs,  Bmaxs0, levels=[12.5, 13.,13.5, 14., 14.5 ,15., 15.5, 16.], colors='white', linestyles="--", linewidths=2)
# ax.clabel(CS)

CS = ax.contour(DLums/Mpcs, MBHs,  Bmaxs0, levels=[12.5, 13.,13.5, 14., 14.5 ,15., 15.5, 16.], colors='grey', linestyles="--", linewidths=2)
# Recast levels to new class
CS.levels = [nf(val) for val in CS.levels]
# fig.colorbar(CSf)


#ax.clabel(CS, inline=True, fmt=fmt, colors="black", fontsize=14)
ax.clabel(CS, inline=True, fmt=fmt, colors="grey", fontsize=14)


#GW200105, #GW200115
plt.errorbar(datx, daty, yerr=yerrs, xerr=xerrs, linestyle='none', color="teal", marker=".", linewidth=3)
plt.errorbar(DL_UL0/Mpcs, MBH_UL0, xerr=15, yerr=15*12./450., uplims=True, xuplims=True, linestyle='-', linewidth=2, color="teal", marker='.')

plt.plot(DLums_hlv , erlipseplt, color="teal", linestyle=":")


xs0 = np.linspace(50, 500, 10)
CSc = ax.contour(DLums/Mpcs, MBHs,  Bmaxs0, levels=[BNS_upper_lim0], colors='tab:purple', linestyles="-", linewidths=4)


# plt.xlim(50,500)
# plt.ylim(5,15)

plt.xlabel(r'$D_L [\mathrm{Mpc}]$')
plt.ylabel(r'$M_{\mathrm{BH}}/M_{\odot}$')

if (wchcase=="pesim"):
    Bexp = 15
else:
    Bexp = 14
prenum = 10**BNS_upper_lim0/10**Bexp 

# plt.figtext(0.15,0.85, r"$B_{\max} \leq %0.2f \times 10^{%g}$~G" %(prenum, Bexp), fontsize=12, color='red')
# plt.figtext(0.15,0.8, r"$S=%g$" %spin_parm0, fontsize=12, color='black')
# plt.figtext(0.15,0.75, r"Spec="+whichUL, fontsize=12, color='black')
# plt.figtext(0.15,0.75, r"$B_{\max} = %0.2f \times 10^{%g}$~G" %(prenum, Bexp), fontsize=12, color='red', zorder=20)
# plt.figtext(0.66,0.85, r"$B_{\max} = %0.2f \times 10^{%g}$~G" %(prenum, Bexp), fontsize=16, color='red', zorder=20)
#plt.figtext(0.15,0.85, r"$S_{\mathrm{BH}}=%g$" %spin_parm0, fontsize=14, color='black', zorder=20)
#plt.figtext(0.15,0.8, r"Spec="+whichUL, fontsize=14, color='black', zorder=20)


plt.figtext(0.145,0.805, r"$S_{\mathrm{BH}}=%g$"%spin_parm0+"\n Spec="+whichUL , fontsize=14, color='black', zorder=20, bbox=props)
plt.figtext(0.63,0.845, r"$B_{\max} = %0.2f \times 10^{%g}$~G" %(prenum, Bexp), fontsize=16, color='tab:purple', zorder=20,  bbox=props)


plt.tight_layout()

plt.savefig("Constriant_GW200105_"+whichUL+"_MNSeq%gMsun_spin%g.pdf" %(MNS0print, spin_parm0))

plt.show()


























#GW200115
datx = [310, 310]
daty = [5.9, 5.9] ##FROM LVC paper


xerrs = [[110,110],[150,150]]
yerrs = [[2.1, 2.1],[1.4, 1.4]] ##FROM LVC paper


if (MandelSmith): ##FROM Mandel and Smith paper
    #datx = [310, 310]
    #xerrs = [[110*0.4/2.1,110*0.4/2.1],[150*0.4/1.4,150*0.4/1.4]] #guess
    daty = [7.0, 7.0]
    yerrs = [[0.4, 0.4],[0.4, 0.4]]


xmaxs0 = datx[0] + xerrs[1][0]
xmaxs1 = datx[1] + xerrs[1][1]
xmins0 = datx[0] - xerrs[0][0]
xmins1 = datx[1] - xerrs[0][1]
xmaxs = [xmaxs0, xmaxs1]

ymaxs0 = daty[0] + yerrs[1][0]
ymaxs1 = daty[1] + yerrs[1][1]
ymins0 = daty[0] - yerrs[0][0]
ymins1 = daty[1] - yerrs[0][1]
ymaxs = [ymaxs0, ymaxs1]

zUL1 = bmxflx.DLtoZ(xmaxs1*Mpcs)


##############################
### Get the Upper limit for B on the error ellipse
##############################
#BNS_upper_lim1 = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zUL1, ymaxs1*Msun, MNS1, spin_parm1, bmxflx.asepmin(RNS, ymaxs1*Msun, spin_parm1), OmNS)
#BNS_upper_lim1 = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zUL1, ymaxs1*Msun, MNS1, spin_parm, Pwf.RH(ymaxs1*Msun, spin_parm), OmNS)
DLums_hlv = np.linspace(datx[0], 500., NHRes)
#MBH values on the error ellipse
erlipseplt = yErrEll(DLums_hlv , datx[0], daty[0], xerrs[1][0], yerrs[1][0])[0]
MBH_erlipsep, MBH_erlipsem = yErrEll(DLumsHR/Mpcs, datx[0], daty[0], xerrs[1][0], yerrs[1][0])

BNS_ellpses1 = np.zeros(NHRes)
for i in range(NHRes):
    asepmins1 = bmxflx.asepmin(RNS, MBH_erlipsep[i]*Msun, spin_parm1) + RNS
    r0s1 = nr0*asepmins1
    BNS_ellpses1[i] = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zsHR[i], MBH_erlipsep[i]*Msun, MNS1, spin_parm1, asepmins1, OmNS, r0s1)

iUL1 = np.argmax(BNS_ellpses1)
MBH_UL1 = MBH_erlipsep[iUL1]
zs_UL1 = zsHR[iUL1]
DL_UL1 = bmxflx.DL(zs_UL1, hub, Om, OL)
asepmin_crit1 = bmxflx.asepmin(RNS, MBH_UL1*Msun, spin_parm1) + RNS
r0_crit1 = nr0*asepmin_crit1
BNS_upper_lim1 = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zs_UL1 , MBH_UL1*Msun, MNS1, spin_parm1, asepmin_crit1, OmNS, r0_crit1)
##############################
##############################








fig, ax = plt.subplots()
if (wchcase=="optim"):
    # plt.title(r'GW200115; $\log_{10} \left(B_{\max} [\mathrm{Gauss}]\right)$', fontsize=14)
    plt.title(r'GW200115; $\log_{10} \left(B_{\max} [\mathrm{G}]\right)$; Optimistic', fontsize=14)
else:
    plt.title(r'GW200115; $\log_{10} \left(B_{\max} [\mathrm{G}]\right)$; Pessimistic', fontsize=14)

# CSf = ax.contourf(DLums/Mpcs, MBHs,  Bmaxs1, 100, cmap='viridis_r')
# CS = ax.contour(DLums/Mpcs, MBHs,  Bmaxs1, levels=[12.5, 13.,13.5, 14., 14.5 ,15., 15.5, 16.], colors='white', linestyles="--", linewidths=2)

#CSf = ax.contourf(DLums/Mpcs, MBHs,  Bmaxs1, 100, cmap='viridis_r')
CS = ax.contour(DLums/Mpcs, MBHs,  Bmaxs1, levels=[12.5, 13.,13.5, 14., 14.5 ,15., 15.5, 16.], colors='grey', linestyles="--", linewidths=2)


# Recast levels to new class
CS.levels = [nf(val) for val in CS.levels]
# fig.colorbar(CSf)

#ax.clabel(CS, inline=True, fmt=fmt, colors="black", fontsize=14)
ax.clabel(CS, inline=True, fmt=fmt, colors="grey", fontsize=14)



plt.errorbar(datx, daty, yerr=yerrs, xerr=xerrs, linestyle='none', color="#d95f0e", marker=".", linewidth=3)
plt.errorbar(DL_UL1/Mpcs, MBH_UL1, xerr=15, yerr=15*12./450., uplims=True, xuplims=True, linestyle='-', linewidth=2, color="#d95f0e", marker='.')
## Error ellipse
plt.plot(DLums_hlv , erlipseplt, color="#d95f0e", linestyle=":")
#plt.plot(DLumsHR/Mpcs, erlipsem, color="black")


xs0 = np.linspace(50, 500, 10)
CSc = ax.contour(DLums/Mpcs, MBHs,  Bmaxs1, levels=[BNS_upper_lim1], colors='tab:purple', linestyles="-", linewidths=4)


# plt.xlim(50,500)
# plt.ylim(5,15)

plt.xlabel(r'$D_L [\mathrm{Mpc}]$')
plt.ylabel(r'$M_{\mathrm{BH}}/M_{\odot}$')

if (wchcase=="pesim"):
    Bexp = 15
else:
    Bexp = 14
prenum = 10**BNS_upper_lim1/10**Bexp 


# plt.figtext(0.15,0.85, r"$S_{\mathrm{BH}}=%g$" %spin_parm1, fontsize=14, color='black', zorder=20)
# plt.figtext(0.15,0.8, r"Spec="+whichUL, fontsize=14, color='black', zorder=20)
# # plt.figtext(0.15,0.75, r"$B_{\max} = %0.2f \times 10^{%g}$~G" %(prenum, Bexp), fontsize=12, color='red', zorder=20)
# plt.figtext(0.64,0.85, r"$B_{\max} = %0.2f \times 10^{%g}$~G" %(prenum, Bexp), fontsize=16, color='tab:purple', zorder=20)


plt.figtext(0.145,0.805, r"$S_{\mathrm{BH}}=%g$"%spin_parm1+"\n Spec="+whichUL , fontsize=14, color='black', zorder=20, bbox=props)
#plt.figtext(0.15,0.8, r"Spec="+whichUL, fontsize=14)#, color='black', zorder=20)

plt.figtext(0.63,0.845, r"$B_{\max} = %0.2f \times 10^{%g}$~G" %(prenum, Bexp), fontsize=16, color='tab:purple', zorder=20,  bbox=props)



plt.tight_layout()

plt.savefig("Constriant_GW200115_"+whichUL+"_MNSeq%gMsun_spin%g.pdf" %(MNS1print, spin_parm1))

plt.show()


















# rgUL1 = (G*MBH_UL1*Msun/c**2)
# r0_min = 1.0 #G*MBH_UL*Msun/c**2
# r0_max1 = asepmin_crit1/rgUL1
# r0_Var1 = np.linspace(r0_min, r0_max1, 10)

# BNS_upper1_rFB0s = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zs_UL1 , MBH_UL1*Msun, MNS1, spin_parm1, asepmin_crit1, OmNS, r0_Var1*rgUL1)


# plt.figure()
# plt.plot(r0_Var, BNS_upper1_rFB0s)
# plt.show()


























# erlipsep, erlipsem = yErrEll(DLumsHR/Mpcs, datx[0], daty[0], xerrs[0][1], yerrs[0][1])


# plt.figure()
# plt.plot(DLumsHR/Mpcs, erlipsep)
# plt.plot(DLumsHR/Mpcs, erlipsem)
# plt.show()






# fig, ax = plt.subplots()
# plt.title(r'GW200115; $\log_{10} \left(B_{\max} [\mathrm{Gauss}]\right)$', fontsize=14)
# CSf = ax.contourf(DLums, MBHs,  np.log10(Bmaxs1), 100)
# CS = ax.contour(DLums, MBHs,  np.log10(Bmaxs1), levels=[12.5, 13.,13.5, 14., 14.5 ,15., 15.5], colors='white', linestyles="--", linewidths=2)
# # ax.clabel(CS)

# # Recast levels to new class
# CS.levels = [nf(val) for val in CS.levels]
# fig.colorbar(CSf)

# # Label levels with specially formatted floats
# if plt.rcParams["text.usetex"]:
#     fmt = r'$%r$'
# else:
#     fmt = '%r'

# ax.clabel(CS, inline=True, fmt=fmt, colors="black", fontsize=14)
# #ax.clabel(CS, CS.levels, inline=True, fmt=fmt, fontsize=14)

# # #ax.clabel(CS,fontsize=14)
# # plt.scatter(49, 10)
# # plt.scatter(270, 10)

# datx = [310, 310]
# daty = [5.9, 5.9]

# xerrs = [[110,110],[150,150]]
# yerrs = [[2.1, 2.1],[1.4, 1.4]]

# xmaxs0 = datx[0] + xerrs[1][0]
# xmaxs1 = datx[1] + xerrs[1][1]
# xmins0 = datx[0] - xerrs[0][0]
# xmins1 = datx[1] - xerrs[0][1]
# xmaxs = [xmaxs0, xmaxs1]

# ymaxs0 = daty[0] + yerrs[1][0]
# ymaxs1 = daty[1] + yerrs[1][1]
# ymins0 = daty[0] - yerrs[0][0]
# ymins1 = daty[1] - yerrs[0][1]
# ymaxs = [ymaxs0, ymaxs1]


# #BNS_upper_lim1 = np.log10(Pwf.Bmax(Flx_UL1, xmaxs1*Mpcs, ymaxs1*Msun, MNS1, spin_parm, Pwf.RH(ymaxs1*Msun, spin_parm), OmNS))


# plt.errorbar(datx, daty, yerr=yerrs, xerr=xerrs, linestyle='none', color="black", marker=".")
# plt.errorbar(xmaxs, ymaxs, xerr=100, yerr=100*12./450., uplims=True, xuplims=True, linestyle='none', color="cornflowerblue", marker='.')



# xs0 = np.linspace(50, 500, 10)
# #plt.fill_between(xs0, BNS_upper_lim, 500, color='grey', alpha=0.5)
# #CSc = ax.contour(DLums, MBHs,  np.log10(Bmaxs1), levels=[BNS_upper_lim1], colors='red', linestyles="-", linewidths=4)



# plt.xlim(50,500)
# plt.ylim(3,15)

# plt.xlabel(r'$D_L [\mathrm{Mpc}]$')
# plt.ylabel(r'$M_{\mathrm{BH}}/M_{\odot}$')

# plt.tight_layout()

# plt.savefig("Constriant_GW200115_MNSeq%gMsun.pdf" %MNS1print)

# plt.show()


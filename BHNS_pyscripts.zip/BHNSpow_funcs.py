import numpy as np
import scipy as sc
import matplotlib
#matplotlib.use('Agg')

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
matplotlib.rcParams['font.family'] = 'sans-serif'
matplotlib.rcParams['font.sans-serif'] = ['Helvetica']
matplotlib.rcParams.update({'font.size': 16})
import matplotlib.pyplot as plt

plt.rcParams.update({
    "text.usetex": True,
    "font.family": "sans-serif",
    "font.sans-serif": ["Helvetica"]})

################################################
#Physical Constants
################################################
G    = 6.67384*10.**(-8)
c    = 2.99792458*10.**(10)
Msun = 1.989*10.**33
eVperErg = 1./6.242e+11

def RH(MBH, spin_parm):
    return G*MBH/c**2 * (1. + np.sqrt( 1. - spin_parm**2) )


def Omorb(MBH, MNS, asep):
    return np.sqrt(G*(MBH+MNS)/asep**3)

def VH(BNS, MBH, MNS, spin_parm, asep, OmNS):
    RNS = 10.**6 #10km
    r = max(asep, RNS)
    return 2. * RH(MBH, spin_parm) * ( r*(Omorb(MBH, MNS, asep) - OmNS)/c + spin_parm/(4.*np.sqrt(2.)) ) * BNS * (RNS/r)**3


def Pow_supply(BNS, MBH, MNS, spin_parm, asep, OmNS):
    ResBH = 4.*np.pi/c
    ResNS = ResBH ##Impedence matching
    return (VH(BNS, MBH, MNS, spin_parm, asep, OmNS))**2/(ResBH + ResNS)**2 * ResNS


def FLux0(DL, BNS, MBH, MNS, spin_parm, asep, OmNS):
    Pow_supply(BNS, MBH, MNS, spin_parm, asep, OmNS)/(4.*np.pi*DL**2)



def Bmax(Flx_UL, Dlum, MBH, MNS, spin_parm, asep, OmNS):
    RNS = 10.**6 #10km
    r = max(asep, RNS)

    ResBH = 4.*np.pi/c
    ResNS = ResBH ##Impedence matching

    BEAM_FAC = 0.01
    #BEAM_FAC = 1.0
    #charE = 0.24*np.sqrt(BNS/10**12) ##MeV from 2016 paper
    ## from GCN for GW200105
    # Hard_short = 11. 
    # Soft_long = 0.4 
    # #Flx_UL = Soft_long * 10**(-7)#   
    # Flx_UL = Hard_short * 10**(-7)#Flx_UL_phsec * charE *eVperErg ##phot/sec * 10^6 eV/phot * erg/ev
    
    PUL = Flx_UL * BEAM_FAC*4.*np.pi*Dlum**2
   
    VH = np.sqrt(PUL*(ResBH + ResNS)**2/ResNS)

    dnm = 2. * RH(MBH, spin_parm) * (   r*(Omorb(MBH, MNS, asep) - OmNS)/c + spin_parm/( 4.*np.sqrt(2.) )   )

    return VH * (r/RNS)**3 / dnm


##################################
## add in depenece of flux on Energy of photonts thtough BNS
##################################
def Bmax_Flxdep(Flx_UL_phsec, Dlum, MBH, MNS, spin_parm, asep, OmNS):
    RNS = 10.**6 #10km
    r = max(asep, RNS)

    ResBH = 4.*np.pi/c
    ResNS = ResBH ##Impedence matching

    BEAM_FAC = 0.01 ##~ cheat matches more complicated calc for now
    #BEAM_FAC = 1.0
    #2.7/2.8 converts most prob photon energy to avg photon energy
    charE = 2.7/2.8* 0.24*np.sqrt(1./10**12) * 10**6 ##MeV from 2016 paper
    Flx_UL = Flx_UL_phsec * charE * eVperErg ##phot/sec * 10^6 eV/phot * erg/ev
    
    PUL =  Flx_UL * BEAM_FAC*4.*np.pi*Dlum**2
   
    VH = np.sqrt(PUL*(ResBH + ResNS)**2/ResNS)

    dnm = 2. * RH(MBH, spin_parm) * (   r*(Omorb(MBH, MNS, asep) - OmNS)/c + spin_parm/( 4.*np.sqrt(2.) )   )

    return (VH * (r/RNS)**3 / dnm)**(4./3.)




#phot flux:
# sigma_p = sigmaSB * (20*RZ(3))/(np.pi**4 * kb)
# sigma_p * T**3



################################################
#DIAGNOSTICS
################################################


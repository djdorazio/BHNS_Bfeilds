import numpy as np
import scipy as sc
import matplotlib
#matplotlib.use('Agg')

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
matplotlib.rcParams['font.family'] = 'sans-serif'
matplotlib.rcParams['font.sans-serif'] = ['Helvetica']
matplotlib.rcParams.update({'font.size': 16})
import matplotlib.pyplot as plt

plt.rcParams.update({
    "text.usetex": True,
    "font.family": "sans-serif",
    "font.sans-serif": ["Helvetica"]})



import Bmax_Flux_integral_funcs as bmxflx
import BHNSpow_funcs as Pwf


class nf(float):
    def __repr__(self):
        s = f'{self:.1f}'
        return f'{self:.0f}' if s[-1] == '0' else s



################################################
#Physical Constants
################################################
G    = 6.67384*10.**(-8)
c    = 2.99792458*10.**(10)
Msun = 1.989*10.**33
hplnk = 6.62607*10**(-27) ##(*Planks constant (erg * s)  *)
kb = 1.3807*10**(-16)
me = 9.109*10**(-28)
sigT = 6.652*10**(-25) #(*Thompson scattering cross section 
sigSB = 5.670*10**(-5) #Stef Boltz

pc2cm = 3.08567758*10**(18)
eVperErg = 1./6.242e+11


###
#How to calc disruption of the NS?
dcase = "Fouc" 
#dcase = "Newt"
# Newt = False
# Fouc = True

################################################
#System Constants
################################################
#DD Jan 18, 2022 -- these were used in the first version of the paper (that was accepted as is), but these are the magnitude of the BH spin, 
# and not the component aligned with the orbital angular momentum
spin_av0 = 0.09 ## GW200105
spin_av1 = 0.31 ## GW200115

spin_max0 = 0.27 ## GW200105
spin_max1 = 0.83 ## GW200115
#DD Jan 18, 2022 -- so if we want the component aligned with orbital angular momentum, then we can assume that the NS spin is 0
# and rearrange the expression for chi_eff, to get chi_1,z (Bh spin component aligned with orbital angular momentum)
#This is computed in teh mathematica notebook called chi_aligned.nb
spin_av0 = -0.012 ## GW200105
spin_av1 = -0.173 ## GW200115

spin_max0 = -0.012 + 0.097 ## GW200105
spin_max1 = -0.173 + 0.216 ## GW200115


##high spin priors:
# spin_av0 = 0.08 ## GW200105
# spin_av1 = 0.33 ## GW200115

# spin_max0 = 0.30 ## GW200105
# spin_max1 = 0.81 ## GW200115

RNS = 10**6
MNStst = 1.35


MBH0 = 8.9
MBHerr0p = 1.1
MBHerr0m = 1.3

MNS0 = 1.9
MNSerr0p = 0.2 
MNSerr0m = 0.2



MBH1 = 5.9
MBHerr1p = 1.4 
MBHerr1m = 2.1

MNS1 = 1.4
MNSerr1p = 0.6 
MNSerr1m = 0.2

datx = [MBH0, MBH1]
daty = [MNS0, MNS1]

xerrs = [[MBHerr0m,MBHerr1m],[MBHerr0p,MBHerr1p]]
yerrs = [[MNSerr0m, MNSerr1m],[MNSerr0p, MNSerr1p]]

xmaxs0 = datx[0] + xerrs[1][0]
xmaxs1 = datx[1] + xerrs[1][1]
xmins0 = datx[0] - xerrs[0][0]
xmins1 = datx[1] - xerrs[0][1]
xmaxs = [xmaxs0, xmaxs1]

ymaxs0 = daty[0] + yerrs[1][0]
ymaxs1 = daty[1] + yerrs[1][1]
ymins0 = daty[0] - yerrs[0][0]
ymins1 = daty[1] - yerrs[0][1]
ymaxs = [ymaxs0, ymaxs1]




#GW200105
datx0 = [MBH0, MBH0]
daty0 = [MNS0, MNS0]

xerrs0 = [[MBHerr0m,MBHerr0m],[MBHerr0p,MBHerr0p]]
yerrs0 = [[MNSerr0m, MNSerr0m],[MNSerr0p, MNSerr0p]]

xmaxs00 = datx0[0] + xerrs0[1][0]
xmaxs10 = datx0[1] + xerrs0[1][1]
xmins00 = datx0[0] - xerrs0[0][0]
xmins10 = datx0[1] - xerrs0[0][1]
xmaxs0 = [xmaxs00, xmaxs10]

ymaxs00 = daty0[0] + yerrs0[1][0]
ymaxs10 = daty0[1] + yerrs0[1][1]
ymins00 = daty0[0] - yerrs0[0][0]
ymins10 = daty0[1] - yerrs0[0][1]
ymaxs0 = [ymaxs00, ymaxs10]


#GW200115
datx1 = [MBH1, MBH1]
daty1 = [MNS1, MNS1]

xerrs1 = [[MBHerr1m,MBHerr1m],[MBHerr1p,MBHerr1p]]
yerrs1 = [[MNSerr1m, MNSerr1m],[MNSerr1p, MNSerr1p]]

xmaxs01 = datx1[0] + xerrs1[1][0]
xmaxs11 = datx1[1] + xerrs1[1][1]
xmins01 = datx1[0] - xerrs1[0][0]
xmins11 = datx1[1] - xerrs1[0][1]
xmaxs1 = [xmaxs01, xmaxs11]

ymaxs01 = daty1[0] + yerrs1[1][0]
ymaxs11 = daty1[1] + yerrs1[1][1]
ymins01 = daty1[0] - yerrs1[0][0]
ymins11 = daty1[1] - yerrs1[0][1]
ymaxs1 = [ymaxs01, ymaxs11]










Ngrd = 250


dlt = 1.761
# FracD = 0.295**(1./dlt)
FracD = 0.499**dlt


MBHsF = np.linspace(1,10, Ngrd)
# MBHs = np.linspace(3,15, Ngrd)
MBHs = np.linspace(1,12, Ngrd)
MNSs = np.linspace(1.0, 2.5, Ngrd)
RNSs = np.linspace(9, 14, Ngrd) #kms

Spns = np.zeros([Ngrd,Ngrd])
Spns_MremF = np.zeros([Ngrd,Ngrd])
Spns_RNS = np.zeros([Ngrd,Ngrd])

if (dcase=="Newt"):
#Bmaxs1 = np.zeros([Ngrd,Ngrd])
    for i in range(Ngrd):
        # print("%g/%g" %(i, Ngrd))
        for j in range(Ngrd):
            Spns[j][i] = bmxflx.SDisrupt(MBHs[j]*Msun, MNSs[i]*Msun, RNS)
elif (dcase=="Fouc"):
    for i in range(Ngrd):
        for j in range(Ngrd):
            Spns[j][i] = bmxflx.Sdis_FoucM0(MBHs[j]*Msun, MNSs[i]*Msun, RNS)
            Spns_MremF[j][i] = bmxflx.Sdis_FoucMF(0.25, MBHs[j]*Msun, MNSs[i]*Msun, RNS)
            Spns_RNS[j][i] = bmxflx.Sdis_FoucM0(MBHsF[j]*Msun, MNStst*Msun, RNSs[i]*10**5)
else:
    "How to calc Sdisrupt??"

        




print("Plotting")


# Label levels with specially formatted floats
if plt.rcParams["text.usetex"]:
    fmt = r'$%r$'
else:
    fmt = '%r'


##REPRODUCE FIG 4 FOUCART
if (dcase=="Fouc"):
    fig, ax = plt.subplots()
    CF = ax.contourf(RNSs, MBHsF, Spns_RNS, 100, cmap='inferno')
    fig.colorbar(CF)

    CS = ax.contour(RNSs, MBHsF, Spns_RNS, levels=[0.0, 0.5, 0.7], colors='black', linestyles='-', linewidths=3)
    ax.clabel(CS, inline=True, fmt=fmt, colors="black", fontsize=14)

    CSd = ax.contour(RNSs, MBHsF, Spns_RNS, levels=[0.25, 0.6, 0.8], colors='black', linestyles='--')
    ax.clabel(CSd, inline=True, fmt=fmt, colors="black", fontsize=14)

    plt.xlabel(r'$R_{\mathrm{NS}} [km]$')
    plt.ylabel(r'$M_{\mathrm{BH}}/M_{\odot}$')


    plt.tight_layout()

    plt.savefig("dsrpt_plts/FOUCART2018_check.png")


    #plt.show()












fig, ax = plt.subplots(figsize=[6,5])
#cmapd = np.copy(plt.cm.get_cmap("cividis_r"))# cmapd.set_under('k')

# CF = ax.contourf(MNSs, MBHs, Spns, 40, cmap=plt.cm.viridis_R, extend="both")
#CF = ax.contourf(MNSs, MBHs, Spns, 40, cmap=plt.cm.inferno_r, extend="both")
CF = ax.contourf(MNSs, MBHs, Spns, 40, cmap=plt.cm.Greys, extend="both")

# CF = ax.contourf(MNSs, MBHs, Spns, 40, cmap=plt.cm.cividis_r, extend="both")

# CF.cmap.set_under('red',1.0)
# CF.cmap.set_over('red',1.0)
# CF.cmap.set_bad('red',1.0)
#fig.colorbar(CF)



CS = ax.contour(MNSs, MBHs, Spns, levels=[0.0, 0.5, 0.9, 0.99], colors='white', linestyles='--')
ax.clabel(CS, inline=True, fmt=fmt, colors="white", fontsize=14)
# CS = ax.contour(MNSs, MBHs, Spns, levels=[0.0, 0.5, 0.9, 0.99], colors='k', linestyles='--')
# ax.clabel(CS, inline=True, fmt=fmt, colors='k', fontsize=14)

# CS = ax.contour(MNSs, MBHs, Spns, levels=[0.0, 0.99], colors='white', linestyles='--')
# ax.clabel(CS, inline=True, fmt=fmt, colors="white", fontsize=14)

CS = ax.contour(MNSs, MBHs, Spns_MremF, levels=[0.885, 0.997], colors='tab:red', linestyles='-')
ax.clabel(CS, inline=True, fmt=fmt, colors="tab:red", fontsize=14)


# CS2 = ax.contour(MNSs, MBHs, Spns, levels=[spin_av0, spin_max0], colors='teal', linestyles='--', zorder=20)
# ax.clabel(CS2, inline=True, fmt=fmt, colors="teal", fontsize=14, zorder=20)

# CS3 = ax.contour(MNSs, MBHs, Spns, levels=[spin_av1, spin_max1], colors='#d95f0e', linestyles='--')
# ax.clabel(CS3, inline=True, fmt=fmt, colors="#d95f0e", fontsize=14)

CS2 = ax.contour(MNSs, MBHs, Spns, levels=[spin_max0], colors='teal', linestyles='--', zorder=20)
ax.clabel(CS2, inline=True, fmt=fmt, colors="teal", fontsize=14, zorder=20)

CS3 = ax.contour(MNSs, MBHs, Spns, levels=[spin_max1], colors='#d95f0e', linestyles='--')
ax.clabel(CS3, inline=True, fmt=fmt, colors="#d95f0e", fontsize=14)

ax.errorbar(daty0, datx0, yerr=xerrs0, xerr=yerrs0, linestyle='none', color="teal", marker=".")
ax.errorbar(daty1, datx1, yerr=xerrs1, xerr=yerrs1, linestyle='none', color="#d95f0e", marker=".")
#ax.errorbar(daty, datx, yerr=xerrs, xerr=yerrs, linestyle='none', color="#d95f0e", marker=".") #both


# ## for MBHs=3-15
# plt.figtext(0.355,0.315, 'GW200115', fontsize=12,color="#d95f0e")
# # plt.figtext(0.625,0.575, 'GW200115', fontsize=12,color="#d95f0e")
# plt.figtext(0.6253,0.51, 'GW200105', fontsize=12,color="teal")


## for MBHs=1-12
plt.figtext(0.355,0.515, 'GW200115', fontsize=12,color="#d95f0e")
# plt.figtext(0.625,0.575, 'GW200115', fontsize=12,color="#d95f0e")
plt.figtext(0.618,0.726, 'GW200105', fontsize=12,color="teal")


ax.set_xlabel(r'$M_{\mathrm{NS}}/M_{\odot}$')
ax.set_ylabel(r'$M_{\mathrm{BH}}/M_{\odot}$')

#ax.set_aspect('equal')
plt.tight_layout()

plt.savefig("dsrpt_plts/MinxSBH_to_disrupt_MBHvsMNS"+dcase+".png")

plt.show()



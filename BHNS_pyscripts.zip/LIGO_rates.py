import numpy as np
import scipy as sc
import matplotlib



import Bmax_Flux_integral_funcs as bmxflx
import BHNSpow_funcs as Pwf

################################################
#Physical Constants
################################################
G    = 6.67384*10.**(-8)
c    = 2.99792458*10.**(10)
Msun = 1.989*10.**33
day2sec = 24.*3600.
day2yr = 1./365.25
yr2sec = 3.154*10.**7
pc2cms = 3.08567758*10**(18)
Mpcs = 10**6*pc2cms
Gpcs = 10**9*pc2cms
eVperErg = 1./6.242e+11

hplnk = 6.62607*10**(-27) ##(*Planks constant (erg * s)  *)
kb = 1.3807*10**(-16)
me = 9.109*10**(-28)
sigT = 6.652*10**(-25) #(*Thompson scattering cross section 
sigSB = 5.670*10**(-5) #Stef Boltz


hub = 0.679 # 0.7  
Om = 0.3065#0.3
OL = 1.0-Om #0.7
################################################

#45 +75-33 /Gpc^3/yr
#130+112-69
Lo_rateA = 45.-33.
Md_rateA = 45.
Hi_rateA = 45.+75.

Lo_rateB = 130.-69.
Md_rateB = 130.
Hi_rateB = 130.+112.

z300 = 0.0691
z100 = 0.0228
DCom100 = bmxflx.DL(z100, hub, Om, OL)/(1.+z100)
DCom300 = bmxflx.DL(z300, hub, Om, OL)/(1.+z300)

# print(DCom100/Mpcs)
# print(DCom300/Mpcs)

Lo100A = Lo_rateA*(DCom100/Gpcs)**3
Md100A = Md_rateA*(DCom100/Gpcs)**3
Hi100A = Hi_rateA*(DCom100/Gpcs)**3

Lo100B = Lo_rateB*(DCom100/Gpcs)**3
Md100B = Md_rateB*(DCom100/Gpcs)**3
Hi100B = Hi_rateB*(DCom100/Gpcs)**3

p100A = Hi100A-Md100A
m100A = Md100A-Lo100A

p100B = Hi100B-Md100B
m100B = Md100B-Lo100B



Lo300A = Lo_rateA*(DCom300/Gpcs)**3
Md300A = Md_rateA*(DCom300/Gpcs)**3
Hi300A = Hi_rateA*(DCom300/Gpcs)**3

Lo300B = Lo_rateB*(DCom300/Gpcs)**3
Md300B = Md_rateB*(DCom300/Gpcs)**3
Hi300B = Hi_rateB*(DCom300/Gpcs)**3


p300A = Hi300A-Md300A
m300A = Md300A-Lo300A

p300B = Hi300B-Md300B
m300B = Md300B-Lo300B
# print("100Mpc range: %g -- %g" %(Lo100, Hi100))

print(r"100Mpc range Model A: $%g^{+%g}_{-%g}$" %(Md100A, p100A, m100A))

print(r"100Mpc range Model B: $%g^{+%g}_{-%g}$" %(Md100B, p100B, m100B))


print(r"300Mpc range Model A: $%g^{+%g}_{-%g}$" %(Md300A, p300A, m300A))

print(r"300Mpc range Model B: $%g^{+%g}_{-%g}$" %(Md300B, p300B, m300B))



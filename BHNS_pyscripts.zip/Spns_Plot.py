import numpy as np
import scipy as sc
import matplotlib
#matplotlib.use('Agg')

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
matplotlib.rcParams['font.family'] = 'sans-serif'
matplotlib.rcParams['font.sans-serif'] = ['Helvetica']
matplotlib.rcParams.update({'font.size': 16})
import matplotlib.pyplot as plt

plt.rcParams.update({
    "text.usetex": True,
    "font.family": "sans-serif",
    "font.sans-serif": ["Helvetica"]})



import Bmax_Flux_integral_funcs as bmxflx
import BHNSpow_funcs as Pwf


class nf(float):
    def __repr__(self):
        s = f'{self:.1f}'
        return f'{self:.0f}' if s[-1] == '0' else s



################################################
#Physical Constants
################################################
G    = 6.67384*10.**(-8)
c    = 2.99792458*10.**(10)
Msun = 1.989*10.**33
day2sec = 24.*3600.
day2yr = 1./365.25
yr2sec = 3.154*10.**7
pc2cms = 3.08567758*10**(18)
Mpcs = 10**6*pc2cms
eVperErg = 1./6.242e+11

hplnk = 6.62607*10**(-27) ##(*Planks constant (erg * s)  *)
kb = 1.3807*10**(-16)
me = 9.109*10**(-28)
sigT = 6.652*10**(-25) #(*Thompson scattering cross section 
sigSB = 5.670*10**(-5) #Stef Boltz


hub = 0.679 # 0.7  
Om = 0.3065#0.3
OL = 1.0-Om #0.7


################################################

def yErrEll(x, mux, muy, sigx, sigy):
    XX = ((x-mux)/sigx)**2
    slnp = sigy*np.sqrt(1.-XX) + muy
    slnm = -sigy*np.sqrt(1.-XX) + muy
    return [slnp, slnm]

################################################

################################################
#FLux ULs
################################################
z50 = 0.05754/5.
Dlum50 = bmxflx.DL(z50, hub, Om, OL)

z265=0.05754
Dlum265 = bmxflx.DL(z265, hub, Om, OL)
Dang265 = bmxflx.Dang(z265, hub, Om, OL)
# Dlum265/Mpcs
z331=0.07116
Dlum331 = bmxflx.DL(z331, hub, Om, OL)
Dang331 = bmxflx.Dang(z331, hub, Om, OL)

##alternatively (from Lum at 265 Mpc)
#over 1kev -10 MeV
Hard_short0 = 21.*10**(48) / (4.*np.pi*Dlum265**2) / 10**(-7)
Norm_mid0   = 2.1*10**(48) / (4.*np.pi*Dlum265**2) / 10**(-7)


##alternatively (from Lum at 265 Mpc)
#over 1kev -10 MeV
Hard_short1 = 52.*10**(48) / (4.*np.pi*Dlum331**2) / 10**(-7)
Norm_mid1   = 5.2*10**(48) / (4.*np.pi*Dlum331**2) / 10**(-7)


GBMnumin = 0.008*10**6 * eVperErg/hplnk
GBMnumax = 30.*10**6   * eVperErg/hplnk
# log10numin = np.log10(GBMnumin)
# log10numax = np.log10(GBMnumax)

UL_min = 0.001*10**6 * eVperErg/hplnk
UL_max = 10.000*10**6 * eVperErg/hplnk
log10numin = np.log10(UL_min)
log10numax = np.log10(UL_max)



################################################
### System params
################################################
# spin_parm = 1.0
# if (whichSPn=="SBHmin"):
#     spin_parm0 = 0.0 ## GW200105
#     spin_parm1 = 0.0 ## GW200115
# elif (whichSPn=="SBHmax"):
#     spin_parm0 = 0.30 ## GW200105
#     spin_parm1 = 0.81 ## GW200115
# #MNS = 0.5*(1.9+0.2 + 1.4-0.2)*Msun ## average of lower and upper NS mass limits
MNS0 = 1.9*Msun ## GW200105
MNS1 = 1.4*Msun ## GW200115

RNS = 10.**6
OmNS = 2.*np.pi/1.0 #1 second spin period

################################################

### DEFs for the CODE
# MNSprint = MNS/Msun
MNS0print = MNS0/Msun
MNS1print = MNS1/Msun













################################################
################################################
# Get DL, M upper limit values
################################################
################################################

NHRes = 40 #100


zmin = 0.01
zmax = 0.11

zsHR = np.linspace(zmin, zmax, NHRes)
DlumMin = bmxflx.DL(zmin, hub, Om, OL)
DlumMax = bmxflx.DL(zmax, hub, Om, OL)

DLumsHR = bmxflx.DL(zsHR, hub, Om, OL)


################################################
################################################
#GW200105
################################################
################################################

datx = [280, 280]
daty = [8.9, 8.9]

xerrs = [[110,110],[110,110]]
yerrs = [[1.3, 1.3],[1.1, 1.1]]

xmaxs0 = datx[0] + xerrs[1][0]
xmaxs1 = datx[1] + xerrs[1][1]
xmins0 = datx[0] - xerrs[0][0]
xmins1 = datx[1] - xerrs[0][1]
xmaxs = [xmaxs0, xmaxs1]

ymaxs0 = daty[0] + yerrs[1][0]
ymaxs1 = daty[1] + yerrs[1][1]
ymins0 = daty[0] - yerrs[0][0]
ymins1 = daty[1] - yerrs[0][1]
ymaxs = [ymaxs0, ymaxs1]


##############################
### Get the Upper limit for B on the error ellipse
##############################
zUL0 = bmxflx.DLtoZ(xmaxs0*Mpcs)
DLums_hlv = np.linspace(datx[0], 500., NHRes)

#MBH values on the error ellipse
erlipseplt = yErrEll(DLums_hlv , datx[0], daty[0], xerrs[1][0], yerrs[1][0])[0]
MBH_erlipsep, MBH_erlipsem = yErrEll(DLumsHR/Mpcs, datx[0], daty[0], xerrs[1][0], yerrs[1][0])

BNS_ellpses0 = np.zeros(NHRes)
for i in range(NHRes):
    asepmins0 = bmxflx.asepmin(RNS, MBH_erlipsep[i]*Msun, spin_parm0) + RNS
    r0s0 = 0.5*asepmins0
    BNS_ellpses0[i] = bmxflx.Bmax_apx(Flx_UL0, log10numin, log10numax, zsHR[i], MBH_erlipsep[i]*Msun, MNS0, spin_parm0, asepmins0, OmNS, r0s0)

iUL0 = np.argmax(BNS_ellpses0)
MBH_UL0 = MBH_erlipsep[iUL0]
zs_UL0 = zsHR[iUL0]
DL_UL0 = bmxflx.DL(zs_UL0, hub, Om, OL)





##############################
##############################
#GW200115
##############################
##############################
datx = [310, 310]
daty = [5.9, 5.9]

xerrs = [[110,110],[150,150]]
yerrs = [[2.1, 2.1],[1.4, 1.4]]

xmaxs0 = datx[0] + xerrs[1][0]
xmaxs1 = datx[1] + xerrs[1][1]
xmins0 = datx[0] - xerrs[0][0]
xmins1 = datx[1] - xerrs[0][1]
xmaxs = [xmaxs0, xmaxs1]

ymaxs0 = daty[0] + yerrs[1][0]
ymaxs1 = daty[1] + yerrs[1][1]
ymins0 = daty[0] - yerrs[0][0]
ymins1 = daty[1] - yerrs[0][1]
ymaxs = [ymaxs0, ymaxs1]

zUL1 = bmxflx.DLtoZ(xmaxs1*Mpcs)


##############################
### Get the Upper limit for B on the error ellipse
##############################
#BNS_upper_lim1 = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zUL1, ymaxs1*Msun, MNS1, spin_parm1, bmxflx.asepmin(RNS, ymaxs1*Msun, spin_parm1), OmNS)
#BNS_upper_lim1 = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zUL1, ymaxs1*Msun, MNS1, spin_parm, Pwf.RH(ymaxs1*Msun, spin_parm), OmNS)
DLums_hlv = np.linspace(datx[0], 500., NHRes)
#MBH values on the error ellipse
erlipseplt = yErrEll(DLums_hlv , datx[0], daty[0], xerrs[1][0], yerrs[1][0])[0]
MBH_erlipsep, MBH_erlipsem = yErrEll(DLumsHR/Mpcs, datx[0], daty[0], xerrs[1][0], yerrs[1][0])

BNS_ellpses1 = np.zeros(NHRes)
for i in range(NHRes):
    asepmins1 = bmxflx.asepmin(RNS, MBH_erlipsep[i]*Msun, spin_parm1) + RNS
    r0s1 = 0.5*asepmins1
    BNS_ellpses1[i] = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zsHR[i], MBH_erlipsep[i]*Msun, MNS1, spin_parm1, asepmins1, OmNS, r0s1)

iUL1 = np.argmax(BNS_ellpses1)
MBH_UL1 = MBH_erlipsep[iUL1]
zs_UL1 = zsHR[iUL1]
DL_UL1 = bmxflx.DL(zs_UL1, hub, Om, OL)



################################################
################################################
# Got DL, M upper limit values^
################################################
################################################


### VARY SPIN

Nprm = 20
Spns= np.linspace(0.0, Nprm)
BNS_Spns0 = np.zeros(Nprm)
BNS_Spns1 = np.zeros(Nprm)

if (var_FUL):
    for i in range(Nprm):
        RHoriz1 = Pwf.RH(MBH_UL1*Msun, Spns[i])
        BNS_Spns0[i] = bmxflx.Bmax_apx(Flx_UL0, log10numin, log10numax, zs_UL0, MBH_UL0*Msun, MNS0, Spns[i], RHoriz0+RNS, OmNS, RHoriz0+RNS)
        BNS_Spns1[i] = bmxflx.Bmax_apx(Flx_UL1, log10numin, log10numax, zs_UL1, MBH_UL1*Msun, MNS1, Spns[i], RHoriz1+RNS, OmNS, RHoriz1+RNS)


plt.figure()

plt.plot(Spns, BNS_Spns0, color='teal')
plt.plot(Spns, BNS_Spns1, color='#d95f0e')

plt.show()

import numpy as np
import scipy as sc
import matplotlib
#matplotlib.use('Agg')

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
matplotlib.rcParams['font.family'] = 'sans-serif'
matplotlib.rcParams['font.sans-serif'] = ['Helvetica']
matplotlib.rcParams.update({'font.size': 16})
import matplotlib.pyplot as plt

plt.rcParams.update({
    "text.usetex": True,
    "font.family": "sans-serif",
    "font.sans-serif": ["Helvetica"]})



import BHNSpow_funcs as Pwf


class nf(float):
    def __repr__(self):
        s = f'{self:.1f}'
        return f'{self:.0f}' if s[-1] == '0' else s



################################################
#Physical Constants
################################################
G    = 6.67384*10.**(-8)
c    = 2.99792458*10.**(10)
Msun = 1.989*10.**33
day2sec = 24.*3600.
day2yr = 1./365.25
yr2sec = 3.154*10.**7
pc2cms = 3.086*10**18
Mpcs = 10**6*pc2cms
eVperErg = 1./6.242e+11
################################################


################################################
###FERMI UPPER LIMITS FROM GCN
### GW200105 (bigger BHmass) -- 82% of localizaiton zone covered
Hard_short0 = 11. 
Norm_mid0 = 1.8
Soft_long0 = 0.4 

#Flx_UL0 = Soft_long0 * 10**(-7)
#Flx_UL0 = Norm_mid0 * 10**(-7)
Flx_UL0 = Hard_short0 * 10**(-7)



### GW200115 (smaller BHmass)
#3 sigma upper limits
Hard_short1 = 17. 
Norm_mid1 = 2.8
Soft_long1 = 0.5 

#Flx_UL1 = Soft_long1 * 10**(-7)
#Flx_UL1 = Norm_mid1 * 10**(-7)
Flx_UL1 = Hard_short1 * 10**(-7)


################################################
################################################






spin_parm = 0.0
#MNS = 0.5*(1.9+0.2 + 1.4-0.2)*Msun ## average of lower and upper NS mass limits
MNS0 = 1.9*Msun ## GW1
MNS1 = 1.4*Msun ## GW2

OmNS = 1.0

# MNSprint = MNS/Msun
MNS0print = MNS0/Msun
MNS1print = MNS1/Msun


Ngrd = 100
l10BNSs = np.linspace(12,14,Ngrd)
MBHs = np.linspace(3,15,Ngrd)
DLums = np.linspace(40,500, Ngrd)
RHaseps = Pwf.RH(MBHs*Msun, spin_parm)

#charE = 0.24*np.sqrt(BNS/10**12) ##MeV
# FermiMin = 0.5*10**6*eVperErg ##phot/sec * 10^6 eV/phot * erg/ev



# PowBM = np.zeros([Ngrd,Ngrd])
# for i in range(Ngrd):
#         for j in range(Ngrd):
#             PowBM[j][i] = Pwf.Pow_supply(10**l10BNSs[i], MBHs[j]*Msun, MNS, spin_parm, RHaseps[j], OmNS)



# DL = 300*Mpcs
# FluxUL = 10**48/(4.*np.pi*DL**2)
# FluxUL = 10**49/(0.1*4.*np.pi*DL**2)

Bmaxs0 = np.zeros([Ngrd,Ngrd])
Bmaxs1 = np.zeros([Ngrd,Ngrd])
for i in range(Ngrd):
        for j in range(Ngrd):
            ##use Fermi sens in photons/sec/cm^2
            # Bmaxs0[j][i] = Pwf.Bmax(0.5, DLums[i]*Mpcs, MBHs[j]*Msun, MNS0, spin_parm, RHaseps[j], OmNS)
            # Bmaxs1[j][i] = Pwf.Bmax(0.5, DLums[i]*Mpcs, MBHs[j]*Msun, MNS1, spin_parm, RHaseps[j], OmNS)

            ## use diff upper limits from FERMI GCN          
            Bmaxs0[j][i] = Pwf.Bmax(Flx_UL0, DLums[i]*Mpcs, MBHs[j]*Msun, MNS0, spin_parm, RHaseps[j], OmNS)
            Bmaxs1[j][i] = Pwf.Bmax(Flx_UL1, DLums[i]*Mpcs, MBHs[j]*Msun, MNS1, spin_parm, RHaseps[j], OmNS)
















fig, ax = plt.subplots()
plt.title(r'GW200105; $\log_{10} \left(B_{\max} [\mathrm{Gauss}]\right)$', fontsize=14)
CSf = ax.contourf(DLums, MBHs,  np.log10(Bmaxs0), 100)
CS = ax.contour(DLums, MBHs,  np.log10(Bmaxs0), levels=[12.5, 13.,13.5, 14., 14.5 ,15., 15.5], colors='white', linestyles="--", linewidths=2)
# ax.clabel(CS)

# Recast levels to new class
CS.levels = [nf(val) for val in CS.levels]
fig.colorbar(CSf)

# Label levels with specially formatted floats
if plt.rcParams["text.usetex"]:
    fmt = r'$%r$'
else:
    fmt = '%r'

ax.clabel(CS, inline=True, fmt=fmt, colors="black", fontsize=14)
#ax.clabel(CS, CS.levels, inline=True, fmt=fmt, fontsize=14)

# #ax.clabel(CS,fontsize=14)
# plt.scatter(49, 10)
# plt.scatter(270, 10)

datx = [280, 280]
daty = [8.9, 8.9]

xerrs = [[110,110],[110,110]]
yerrs = [[1.3, 1.3],[1.1, 1.1]]

xmaxs0 = datx[0] + xerrs[1][0]
xmaxs1 = datx[1] + xerrs[1][1]
xmins0 = datx[0] - xerrs[0][0]
xmins1 = datx[1] - xerrs[0][1]
xmaxs = [xmaxs0, xmaxs1]

ymaxs0 = daty[0] + yerrs[1][0]
ymaxs1 = daty[1] + yerrs[1][1]
ymins0 = daty[0] - yerrs[0][0]
ymins1 = daty[1] - yerrs[0][1]
ymaxs = [ymaxs0, ymaxs1]


BNS_upper_lim0 = np.log10(Pwf.Bmax(Flx_UL0, xmaxs0*Mpcs, ymaxs0*Msun, MNS0, spin_parm, Pwf.RH(ymaxs0*Msun, spin_parm), OmNS))

#GW200105, #GW200115
plt.errorbar(datx, daty, yerr=yerrs, xerr=xerrs, linestyle='none', color="black", marker=".")
plt.errorbar(xmaxs, ymaxs, xerr=100, yerr=100*12./450., uplims=True, xuplims=True, linestyle='none', color="cornflowerblue", marker='.')

# xs0 = np.linspace(xmins0, xmaxs0, 10)
# plt.fill_between(xs0, ymins0, ymaxs0, color='grey', alpha=0.7)
# xs1 = np.linspace(xmins1, xmaxs1, 10)
# plt.fill_between(xs1, ymins1, ymaxs1, color='grey', alpha=0.7)

# xs0u = np.linspace(50, 500, 10)
# xs0r = np.linspace(xmaxs0, 500, 10)
# plt.fill_between(xs0u, ymaxs0, 15, color='grey', alpha=0.5)
# plt.fill_between(xs0r, 3,      ymaxs0, color='grey', alpha=0.5)

xs0 = np.linspace(50, 500, 10)
#plt.fill_between(xs0, BNS_upper_lim, 500, color='grey', alpha=0.5)
CSc = ax.contour(DLums, MBHs,  np.log10(Bmaxs0), levels=[BNS_upper_lim0], colors='red', linestyles="-", linewidths=4)

# iverbot = np.where(np.log10(Bmaxs0)>=BNS_upper_lim)[0]



#GW200115
# plt.errorbar(280, 5.9, xerr=[110,150], yerr=[2.1,1.4])

# plt.scatter(270, 10)

plt.xlim(50,500)
plt.ylim(3,15)

plt.xlabel(r'$D_L [\mathrm{Mpc}]$')
plt.ylabel(r'$M_{\mathrm{BH}}/M_{\odot}$')

plt.tight_layout()

plt.savefig("Constriant_GW200105_MNSeq%gMsun.pdf" %MNS0print)

plt.show()











fig, ax = plt.subplots()
plt.title(r'GW200115; $\log_{10} \left(B_{\max} [\mathrm{Gauss}]\right)$', fontsize=14)
CSf = ax.contourf(DLums, MBHs,  np.log10(Bmaxs1), 100)
CS = ax.contour(DLums, MBHs,  np.log10(Bmaxs1), levels=[12.5, 13.,13.5, 14., 14.5 ,15., 15.5], colors='white', linestyles="--", linewidths=2)
# ax.clabel(CS)

# Recast levels to new class
CS.levels = [nf(val) for val in CS.levels]
fig.colorbar(CSf)

# Label levels with specially formatted floats
if plt.rcParams["text.usetex"]:
    fmt = r'$%r$'
else:
    fmt = '%r'

ax.clabel(CS, inline=True, fmt=fmt, colors="black", fontsize=14)
#ax.clabel(CS, CS.levels, inline=True, fmt=fmt, fontsize=14)

# #ax.clabel(CS,fontsize=14)
# plt.scatter(49, 10)
# plt.scatter(270, 10)

datx = [310, 310]
daty = [5.9, 5.9]

xerrs = [[110,110],[150,150]]
yerrs = [[2.1, 2.1],[1.4, 1.4]]

xmaxs0 = datx[0] + xerrs[1][0]
xmaxs1 = datx[1] + xerrs[1][1]
xmins0 = datx[0] - xerrs[0][0]
xmins1 = datx[1] - xerrs[0][1]
xmaxs = [xmaxs0, xmaxs1]

ymaxs0 = daty[0] + yerrs[1][0]
ymaxs1 = daty[1] + yerrs[1][1]
ymins0 = daty[0] - yerrs[0][0]
ymins1 = daty[1] - yerrs[0][1]
ymaxs = [ymaxs0, ymaxs1]


BNS_upper_lim1 = np.log10(Pwf.Bmax(Flx_UL1, xmaxs1*Mpcs, ymaxs1*Msun, MNS1, spin_parm, Pwf.RH(ymaxs1*Msun, spin_parm), OmNS))


plt.errorbar(datx, daty, yerr=yerrs, xerr=xerrs, linestyle='none', color="black", marker=".")
plt.errorbar(xmaxs, ymaxs, xerr=100, yerr=100*12./450., uplims=True, xuplims=True, linestyle='none', color="cornflowerblue", marker='.')

# xs0 = np.linspace(xmins0, xmaxs0, 10)
# plt.fill_between(xs0, ymins0, ymaxs0, color='grey', alpha=0.7)
# xs1 = np.linspace(xmins1, xmaxs1, 10)
# plt.fill_between(xs1, ymins1, ymaxs1, color='grey', alpha=0.7)

# xs1u = np.linspace(50, 500, 10)
# xs1r = np.linspace(xmaxs1, 500, 10)
# plt.fill_between(xs1u, ymaxs1, 15, color='grey', alpha=0.5)
# plt.fill_between(xs1r, 3,      ymaxs1, color='grey', alpha=0.5)

xs0 = np.linspace(50, 500, 10)
#plt.fill_between(xs0, BNS_upper_lim, 500, color='grey', alpha=0.5)
CSc = ax.contour(DLums, MBHs,  np.log10(Bmaxs1), levels=[BNS_upper_lim1], colors='red', linestyles="-", linewidths=4)



#GW200115
# plt.errorbar(280, 5.9, xerr=[110,150], yerr=[2.1,1.4])

# plt.scatter(270, 10)

plt.xlim(50,500)
plt.ylim(3,15)

plt.xlabel(r'$D_L [\mathrm{Mpc}]$')
plt.ylabel(r'$M_{\mathrm{BH}}/M_{\odot}$')

plt.tight_layout()

plt.savefig("Constriant_GW200115_MNSeq%gMsun.pdf" %MNS1print)

plt.show()

